import React from "react";
import { StyleSheet, Text, View } from "react-native";
import {
  Container,
  Header,
  Left,
  Body,
  Right,
  Button,
  Icon,
  Title,
  ListItem,
  Thumbnail,
} from "native-base";

const ConfirmPayment = (props) => {
  return (
    <View>
      <Header>
        <Left style={{ flexDirection: "row" }}>
          <Button transparent onPress={() => props.navigation.goBack()}>
            <Icon name="arrow-back" />
          </Button>
        </Left>
        <Body>
          <Title>COnfirmed Order</Title>
        </Body>
        <Right></Right>
      </Header>
      <Text>COnfirmed Order</Text>
    </View>
  );
};

export default ConfirmPayment;

const styles = StyleSheet.create({});
