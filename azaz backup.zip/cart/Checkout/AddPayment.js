import React from "react";
import { StyleSheet, Text, View } from "react-native";
import {
  Container,
  Header,
  Left,
  Body,
  Right,
  Button,
  Icon,
  Title,
  ListItem,
  Thumbnail,
} from "native-base";

const AddPayment = (props) => {
  return (
    <View>
      <Header>
        <Left style={{ flexDirection: "row" }}>
          <Button transparent onPress={() => props.navigation.goBack()}>
            <Icon name="arrow-back" />
          </Button>
        </Left>
        <Body>
          <Title>Payment method</Title>
        </Body>
        <Right></Right>
      </Header>
      <Text>Select Payment method</Text>
    </View>
  );
};

export default AddPayment;

const styles = StyleSheet.create({});
