import React from "react";
import { StyleSheet,TouchableOpacity } from "react-native";
import { Text, Left, Right, ListItem, Thumbnail, Body,Icon } from "native-base";

// Redux

const CartItem = (props) => {
  const {item} = props.item;
 console.log(props.item);
  return (
    <ListItem style={styles.listItem}>
      <Body style={styles.body}>
        <Left>
          <Text>{item.productTitle}</Text>
        </Left>
        <Right>
          <Text>x{item.quantity}</Text> 
        </Right>
        <Right>
          <Text>Rs {item.productPrice}</Text>
        </Right>
        <Right>
          <Text>Rs {item.sum}</Text>
        </Right>
        <Right>
          <TouchableOpacity onPress={() => {props.onRemove(item.productId)}}>
            <Icon
              name="delete-forever"
              type="MaterialCommunityIcons"
              style={{ fontSize: 27, color: "red" }}
            />
          </TouchableOpacity>
        </Right>
      </Body>
    </ListItem>
  );
};

const styles = StyleSheet.create({
  listItem: {
    alignItems: "center",
    backgroundColor: "white",
    justifyContent: "center",
  },
  body: {
    margin: 10,
    alignItems: "center",
    flexDirection: "row",
  },
});



export default CartItem;
