import React from "react";
import { StyleSheet,TouchableOpacity } from "react-native";
import { Text, Left, Right, ListItem,Body,Icon } from "native-base";


// Redux

const CartItem = (props) => {
  const {item} = props.item;
  return (
    <ListItem style={styles.listItem}>
      <Body style={styles.body}>
        <Left style={{marginRight:50}}>
          <Text>{item.productTitle}</Text>
        </Left>
        <Body style={styles.body}>
        <TouchableOpacity onPress={() => {props.onDecrement(item.productId)}}>
            <Icon
              name="minus"
              type="EvilIcons"
              style={{ fontSize: 27, color: "red" }}
            />
          </TouchableOpacity>
        <Right>
          <Text>x{item.quantity}</Text> 
        </Right>
        <TouchableOpacity onPress={() => {props.onIncrement(item.productId)}}>
            <Icon
              name="plus"
              type="EvilIcons"
              style={{ fontSize: 27, color: "red" }}
            />
          </TouchableOpacity>
        </Body>
        
        {/* <Right>
          <Text>Rs {item.productPrice}</Text>
        </Right> */}
        <Right>
          <Text>Rs {item.sum}</Text>
        </Right>
        {/* <Right>
          <TouchableOpacity onPress={() => {props.onRemove(item.productId)}}>
            <Icon
              name="delete-forever"
              type="MaterialCommunityIcons"
              style={{ fontSize: 27, color: "red" }}
            />
          </TouchableOpacity>
        </Right> */}
      </Body>
    </ListItem>
  );
};

const styles = StyleSheet.create({
  listItem: {
    alignItems: "center",
    backgroundColor: "white",
    justifyContent: "center",
  },
  body: {
    margin: 10,
    alignItems: "center",
    flexDirection: "row",
  },
});



export default CartItem;
