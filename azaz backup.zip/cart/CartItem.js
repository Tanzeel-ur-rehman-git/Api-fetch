import React, { useState } from "react";
import { StyleSheet,TouchableOpacity } from "react-native";
import { Text, Left, Right, ListItem, Thumbnail, Body,Icon } from "native-base";

// Redux
import { connect } from "react-redux";
import * as actions from "../redux/Actions/cartActions";

const CartItem = (props) => {
  const data = props.item.item.product;
  const data1 = props.item.item;
  console.log(data1)
  return (
    <ListItem style={styles.listItem}  avatar>
      <Left>
        <Thumbnail
          source={
            data.image
              ? {
                  uri:
                    "https://fattafatt.com/uploads/product_images/" +
                    data.image,
                }
              : null
          }
        />
      </Left>
      <Body style={styles.body}>
        <Left>
          <Text>{data.name}</Text>
        </Left>
        <Right>
          <Text>x{data1.quantity}</Text>
        </Right>
        <Right>
          <Text>$ {data.price}</Text>
        </Right>
        <Right>
          <TouchableOpacity onPress={() => props.removeFromCart(data.item)}>
            <Icon
              name="delete-forever"
              type="MaterialCommunityIcons"
              style={{ fontSize: 27, color: "red" }}
            />
          </TouchableOpacity>
        </Right>
      </Body>
    </ListItem>
  );
};

const styles = StyleSheet.create({
  listItem: {
    alignItems: "center",
    backgroundColor: "white",
    justifyContent: "center",
  },
  body: {
    margin: 10,
    alignItems: "center",
    flexDirection: "row",
  },
});

const mapDispatchToProps = (dispatch) => {
  return {
    removeFromCart: (item) => dispatch(actions.removeFromCart(item)),
  };
};

export default connect(null, mapDispatchToProps)(CartItem);
