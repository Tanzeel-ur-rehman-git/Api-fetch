import React from "react";
import { StyleSheet } from "react-native";
import { Badge, Text } from "native-base";

import { useSelector } from "react-redux";



const CartIcon = (props) => {

  // const cartItems = useSelector((state) => {
  //   const transformedCartItems = [];
  //   for (const key in state.cart.items) {
  //     transformedCartItems.push({
  //       productId: key,
  //       productTitle: state.cart.items[key].productTitle,
  //       productPrice: state.cart.items[key].productPrice,
  //       productVenId: state.cart.items[key].productVenId,
  //       quantity: state.cart.items[key].quantity,
  //       sum: state.cart.items[key].sum,
  //     });
  //   }

  //   return transformedCartItems;
  // });

  return (
    <>
      {/* {cartItems.length ? ( */}
        <Badge style={styles.badge}>
          {/* <Text style={styles.text}>{cartItems.length}</Text> */}
        </Badge>
       {/* ) : null} */}
    </>
  );
};

const mapStateToProps = (state) => {
  const { cartItems } = state;
  return {
    cartItems: cartItems,
  };
};

const styles = StyleSheet.create({
  badge: {
    width: 25,
    position: "absolute",
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    alignContent: "center",
    top: -30,
    right: 25,
    opacity:0.5,
  },
  text: {
    fontSize: 12,
    width: 100,
    fontWeight: "bold",
    
  },
});

export default CartIcon;
