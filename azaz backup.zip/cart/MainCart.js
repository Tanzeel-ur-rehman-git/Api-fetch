import React, { Component, useEffect, useState } from "react";
import {
  Container,
  Header,
  Left,
  Body,
  Right,
  Button,
  Icon,
  Title,
  ListItem,
  Thumbnail,
} from "native-base";
// import { DrawerActions } from "@react-navigation/native";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

import { connect } from "react-redux";
import * as actions from "../redux/Actions/cartActions";

const MainCart = (props) => {
  const [checkValue, setcheckValue] = useState(null);

  const tokenlogin = async () => {
    const value = await AsyncStorage.getItem("token");
    if (value !== null) {
      setcheckValue(value);
    } else {
      return null;
    }
  };

  useEffect(() => {
    tokenlogin();
    return () => {};
  }, []);

  var total = 0;
  props.cartItems.forEach((x) => {
    return (total += x.product.price);
  });

 
  console.log(props.cartItems)
  return (
    <Container>
      <Header>
        <Left style={{ flexDirection: "row" }}>
          <Button transparent onPress={() => props.navigation.goBack()}>
            <Icon name="arrow-back" />
          </Button>
        </Left>
        <Body>
          <Title>Cart</Title>
        </Body>
        <Right></Right>
      </Header>
      <View style={{ height: "50%" }}>
        <ScrollView>
          <View>
            {props.cartItems.map((x) => {
              return (
                <ListItem style={styles.listItem} key={Math.random()} avatar>
                  <Left>
                    <Thumbnail
                      source={
                        x.product.image
                          ? {
                              uri:
                                "https://fattafatt.com/uploads/product_images/" +
                                x.product.image,
                            }
                          : null
                      }
                    />
                  </Left>
                  <Body style={styles.body}>
                    <Left>
                      <Text>{x.product.name}</Text>
                    </Left>
                    <Right>
                      <Text>Rs {x.product.price}</Text>
                    </Right>
                    <Right>
                      <TouchableOpacity
                        onPress={() => props.removeFromCart(x.product)}
                      >
                        <Icon
                          name="delete-forever"
                          type="MaterialCommunityIcons"
                          style={{ fontSize: 27, color: "red" }}
                        />
                      </TouchableOpacity>
                    </Right>
                  </Body>
                </ListItem>
              );
            })}
          </View>
        </ScrollView>
      </View>
      <View style={styles.bottomContainer}>
        <Left>
          <Text>RS {total}</Text>
        </Left>
        <Right>
          <Button danger onPress={() => props.clearCart()}>
            <Text>Clear Cart</Text>
          </Button>
        </Right>
        <Right>
          {checkValue == null ? (
            <Button onPress={() => props.navigation.navigate("Login")}>
              <Text>Login</Text>
            </Button>
          ) : (
            <Button>
              <Text>Check Out</Text>
            </Button>
          )}
        </Right>
      </View>
    </Container>
  );
};

const mapStateToProps = (state) => {
  const { cartItems } = state;
  // console.log(cartItems);
  return {
    cartItems: cartItems,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    clearCart: () => dispatch(actions.clearCart()),
    removeFromCart: (item) => dispatch(actions.removeFromCart(item)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(MainCart);

const styles = StyleSheet.create({
  bottomContainer: {
    flexDirection: "row",
    position: "absolute",
    bottom: 0,
    left: 0,
    backgroundColor: "white",
    elevation: 20,
  },
  listItem: {
    alignItems: "center",
    backgroundColor: "white",
    justifyContent: "center",
  },
  body: {
    margin: 10,
    alignItems: "center",
    flexDirection: "row",
  },
});
