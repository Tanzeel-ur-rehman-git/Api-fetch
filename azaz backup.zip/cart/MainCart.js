import React, { Component, useEffect, useState } from "react";
import {
  Container,
  Header,
  Left,
  Body,
  Right,
  Button,
  Icon,
  Title,
  ListItem,
  Thumbnail,
} from "native-base";
// import { DrawerActions } from "@react-navigation/native";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  FlatList,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

// Redux
import { connect } from "react-redux";
import * as actions from "../redux/Actions/cartActions";

//Screen
import CartItem from "../cart/CartItem";

const MainCart = (props) => {
  const [checkValue, setcheckValue] = useState(null);
  const [riderFee, setRiderFee] = useState(0)
  const [gSTapp, setGSTapp] = useState(0)


  const tokenlogin = async () => {
    const value = await AsyncStorage.getItem("token");
    if (value !== null) {
      setcheckValue(value);
    } else {
      return null;
    }
  };

  useEffect(() => {
    tokenlogin();
    return () => {};
  }, []);

  var total = 0;
  props.cartItems.forEach((x) => {
    return (total += parseInt(x.product.price));
  });


  var GST = total * gSTapp;
  var GrandTotal = total + riderFee + GST;

  console.log(props.cartItems);
  return (
    <Container>
      <Header>
        <Left style={{ flexDirection: "row" }}>
          <Button transparent onPress={() => props.navigation.goBack()}>
            <Icon name="arrow-back" />
          </Button>
        </Left>
        <Body>
          <Title>Cart</Title>
        </Body>
        <Right></Right>
      </Header>
      {props.cartItems.length ? (
        <View style={{ height: "55%" }}>
          <FlatList
            data={props.cartItems}
            keyExtractor={(data, index) => "key" + index}
            renderItem={(data) => <CartItem item={data} />}
          />
        </View>
      ) : (
        <View
          style={{ flex: 1, justifyContent: "center", alignItems: "center" }}
        >
          <Text>Cart is Empty</Text>
        </View>
      )}

      <ListItem style={styles.listItem1}>
        <Body style={styles.body}>
          <Left>
            <Text>Total Amount is </Text>
          </Left>
          <Right>
            <Text>RS {total}</Text>
          </Right>
        </Body>
      </ListItem>

      <ListItem style={styles.listItem1}>
        <Body style={styles.body}>
          <Left>
            <Text>Rider Fee for Delivery</Text>
          </Left>
          <Right>
            <Text>RS {riderFee}</Text>
          </Right>
        </Body>
      </ListItem>

      <ListItem style={styles.listItem1}>
        <Body style={styles.body}>
          <Left>
            <Text>Goods and Services Tax </Text>
          </Left>
          <Right>
            <Text>RS {GST.toFixed(2)}</Text>
          </Right>
        </Body>
      </ListItem>

      <ListItem style={styles.listItem}>
        <Body style={styles.body}>
          <Left>
            <Text>Total Payable Amount</Text>
          </Left>
          <Right>
            <Text>RS {GrandTotal}</Text>
          </Right>
        </Body>
      </ListItem>

      <View style={styles.bottomContainer}>
        <Left>
          <Button danger onPress={() => props.clearCart()}>
            <Text>Clear Cart</Text>
          </Button>
        </Left>
        <Right>
          {checkValue == null ? (
            <Button onPress={() => props.navigation.navigate("Login")}>
              <Text>Login</Text>
            </Button>
          ) : (
            <Button disabled={props.cartItems.length === 0}>
              <Text>Check Out</Text>
            </Button>
          )}
        </Right>
      </View>
    </Container>
  );
};

const mapStateToProps = (state) => {
  const { cartItems } = state;
  return {
    cartItems: cartItems,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    clearCart: () => dispatch(actions.clearCart()),
    removeFromCart: (item) => dispatch(actions.removeFromCart(item)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(MainCart);

const styles = StyleSheet.create({
  bottomContainer: {
    flexDirection: "row",
    position: "absolute",
    bottom: 0,
    left: 0,
    backgroundColor: "white",
    elevation: 20,
  },
  listItem: {
    marginTop:15,
    alignItems: "center",
    backgroundColor: "white",
    justifyContent: "center",
  },
  listItem1:{
    alignItems: "center",
    backgroundColor: "white",
    justifyContent: "center",
    marginBottom:-25
  },
  body: {
    margin: 10,
    alignItems: "center",
    flexDirection: "row",
  },
});
