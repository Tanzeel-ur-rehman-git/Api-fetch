import React from 'react'
import { StyleSheet, Text, View } from 'react-native'

const MainCart = (props) => {
    return (
        <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
            <Text>Cart is empty</Text>
        </View>
    )
}

export default MainCart

const styles = StyleSheet.create({})
