import React, { Component, useEffect, useState } from "react";
import {
  Container,
  Header,
  Left,
  Body,
  Right,
  Button,
  Icon,
  Title,
  ListItem,
  Thumbnail,
} from "native-base";
// import { DrawerActions } from "@react-navigation/native";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  FlatList,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

// Redux
import { useSelector, useDispatch } from "react-redux";
import * as actions from "../redux/Actions/cart";
import { removeFromCart } from "../redux/Actions/cart";
import { incrementCart } from "../redux/Actions/cart";
import { decrementCart } from "../redux/Actions/cart";

//Screen
import CartItem from "../cart/CartItem";

const MainCart = (props) => {
  const [checkValue, setcheckValue] = useState(null);
  const [riderFee, setRiderFee] = useState(20)
  const [gSTapp, setGSTapp] = useState(0.17)




  const dispatch = useDispatch();
  const onRemove = (id) => {
    dispatch(removeFromCart(id));
  };
  const onIncrement = (id) => {
    dispatch(incrementCart(id));
  };
  const onDecrement = (id) => {
    dispatch(decrementCart(id));
  };

  const CartTotalAmount = useSelector((state) => state.cart.totalAmount);

  const cartItems = useSelector((state) => {
    const transformedCartItems = [];
    for (const key in state.cart.items) {
      transformedCartItems.push({
        productId: key,
        productTitle: state.cart.items[key].productTitle,
        productPrice: state.cart.items[key].productPrice,
        quantity: state.cart.items[key].quantity,
        sum: state.cart.items[key].sum,
      });
    }

    return transformedCartItems;
  });





  const tokenlogin = async () => {
    const value = await AsyncStorage.getItem("token");
    if (value !== null) {
      setcheckValue(value);
    } else {
      return null;
    }
  };


  useEffect(() => {
    tokenlogin();
    return () => {};
  }, []);

 


  var GST = CartTotalAmount * gSTapp;
  var GrandTotal = CartTotalAmount + riderFee + GST;

  // console.log(cartItems);
  return (
    <Container>
      <Header>
        <Left style={{ flexDirection: "row" }}>
          <Button transparent onPress={() => props.navigation.goBack()}>
            <Icon name="arrow-back" />
          </Button>
        </Left>
        <Body>
          <Title>Cart</Title>
        </Body>
        <Right></Right>
      </Header>
      {cartItems.length ? (
        <View style={{ height: "55%" }}>
          <FlatList
             data={cartItems}
             keyExtractor={(item) => item.productId}
             renderItem={(item) => (
              <CartItem item={item} onRemove={onRemove} onIncrement={onIncrement} onDecrement={onDecrement}/>
            )}
          />
        </View>
      ) : (
        <View
          style={{ flex: 1, justifyContent: "center", alignItems: "center" }}
        >
          <Text>Cart is Empty</Text>
        </View>
      )}

      <ListItem style={styles.listItem1}>
        <Body style={styles.body}>
          <Left>
            <Text>Total Amount is </Text>
          </Left>
          <Right>
            <Text>RS {CartTotalAmount}</Text>
          </Right>
        </Body>
      </ListItem>

      <ListItem style={styles.listItem1}>
        <Body style={styles.body}>
          <Left>
            <Text>Rider Fee for Delivery</Text>
          </Left>
          <Right>
            <Text>RS {riderFee}</Text>
          </Right>
        </Body>
      </ListItem>

      <ListItem style={styles.listItem1}>
        <Body style={styles.body}>
          <Left>
            <Text>Goods and Services Tax </Text>
          </Left>
          <Right>
            <Text>RS {GST.toFixed(0)}</Text>
          </Right>
        </Body>
      </ListItem>

      <ListItem style={styles.listItem}>
        <Body style={styles.body}>
          <Left>
            <Text>Total Payable Amount</Text>
          </Left>
          <Right>
            <Text>RS {GrandTotal}</Text>
          </Right>
        </Body>
      </ListItem>

      <View style={styles.bottomContainer}>
        <Left>
          <Button danger onPress={() => dispatch(actions.clearCart())}>
            <Text>Clear Cart</Text>
          </Button>
        </Left>
        <Right>
          {checkValue == null ? (
            <Button onPress={() => props.navigation.navigate("Login")}>
              <Text>Login</Text>
            </Button>
          ) : (
            <Button disabled={cartItems.length === 0} onPress={()=>props.navigation.navigate('TopTabNavigation')}>
              <Text>Check Out</Text>
            </Button>
          )}
        </Right>
      </View>
    </Container>
  );
};


export default MainCart;

const styles = StyleSheet.create({
  bottomContainer: {
    flexDirection: "row",
    position: "absolute",
    bottom: 0,
    left: 0,
    backgroundColor: "white",
    elevation: 20,
  },
  listItem: {
   
    alignItems: "center",
    backgroundColor: "white",
    justifyContent: "center",
  },
  listItem1:{
    alignItems: "center",
    backgroundColor: "white",
    justifyContent: "center",
    marginBottom:-25
  },
  body: {
    margin: 10,
    alignItems: "center",
    flexDirection: "row",
  },
});
