import React from 'react'
import { StyleSheet, Text, View } from 'react-native'

const DealScreen = (props) => {
    return (
        <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
            <Text>Top Deals are here</Text>
        </View>
    )
}

export default DealScreen

const styles = StyleSheet.create({})
