import React, { Component } from 'react';
import { Container, Header, Left, Body, Right, Button, Icon, Title ,Text} from 'native-base';
import { DrawerActions } from '@react-navigation/native';

const DealScreen = (props) => {
    return (
        <Container>
        <Header >
          <Left style={{flexDirection:'row'}}>
          <Button transparent onPress={() => props.navigation.dispatch(DrawerActions.toggleDrawer())}>
            <Icon
            name="hamburger"
            type="FontAwesome5"
            style={{ fontSize: 35, color: "#ff6347" }}
          />
          </Button>
            <Button transparent onPress={()=> props.navigation.goBack()}>
              <Icon name='arrow-back' />
            </Button>

          </Left>
          <Body>
            <Title>Deals</Title>
          </Body>
          <Right>
       
          </Right>
        </Header>
        <Body>
        <Text>This is Deals Screen</Text>
        </Body>
      </Container>
    )
}

export default DealScreen

// const styles = StyleSheet.create({})
