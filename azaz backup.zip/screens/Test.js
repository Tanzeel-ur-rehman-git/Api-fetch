import React, { useState, useEffect } from 'react';
import { Platform, Text, View, StyleSheet } from 'react-native';
import * as Location from 'expo-location';



const Test = (props) => {
  const [location, setLocation] = useState(null);
  const [locationMessage, setLocationMessage] = useState(null);

  useEffect(() => {
    getLocation();
    return () => {
      setLocation([]);
      setLocationMessage();
    };
  }, []);

  setTimeout(()=>{
    getLocation();
    let speedd = 'Waiting..';
    if (locationMessage) {
      speedd = locationMessage;
    } else if (location) {
      speedd = JSON.stringify(location.coords.speed);
    }
    if(speedd >= 0.10)
    {
        alert('Move on');
    }
  }, 6000);



  const getLocation = async () => {
    let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setLocationMessage('Permission to access location was denied');
        return;
      }

      let location = await Location.getCurrentPositionAsync({});
      setLocation(location);
  };


  let accuracy = 'Waiting..';
  if (locationMessage) {
    accuracy = locationMessage;
  } else if (location) {
    accuracy = JSON.stringify(location.coords.accuracy);
  
  }
 
  let altitude = 'Waiting..';
  if (locationMessage) {
    altitude = locationMessage;
  } else if (location) {
    altitude = JSON.stringify(location.coords.altitude);
   
  }

  let altitudeAccuracy = 'Waiting..';
  if (locationMessage) {
    altitudeAccuracy = locationMessage;
  } else if (location) {
    altitudeAccuracy = JSON.stringify(location.coords.altitudeAccuracy);
    
  }

  let heading = 'Waiting..';
  if (locationMessage) {
    heading = locationMessage;
  } else if (location) {
    heading = JSON.stringify(location.coords.heading);
  
  }

  let latitude = 'Waiting..';
  if (locationMessage) {
    latitude = locationMessage;
  } else if (location) {
    latitude = JSON.stringify(location.coords.latitude);
  
  }

  let longitude = 'Waiting..';
  if (locationMessage) {
    longitude = locationMessage;
  } else if (location) {
    longitude = JSON.stringify(location.coords.longitude);

  }

  let speed = 'Waiting..';
  if (locationMessage) {
    speed = locationMessage;
  } else if (location) {
    speed = JSON.stringify(location.coords.speed);
    
  }

  let mocked = 'Waiting..';
  if (locationMessage) {
    mocked = locationMessage;
  } else if (location) {
    mocked = JSON.stringify(location.mocked);
   
  }

  let timestamp = 'Waiting..';
  if (locationMessage) {
    timestamp = locationMessage;
  } else if (location) {
    timestamp = JSON.stringify(location.timestamp);
    
  }

  return (
     <View style={styles.container}>
      <Text style={styles.paragraph}>accuracy : {accuracy}</Text>
      <Text style={styles.paragraph}>altitude : {altitude}</Text>
      <Text style={styles.paragraph}>altitudeAccuracy : {altitudeAccuracy}</Text>
      <Text style={styles.paragraph}>heading : {heading}</Text>
      <Text style={styles.paragraph}>latitude : {latitude}</Text>
      <Text style={styles.paragraph}>longitude : {longitude}</Text>
      <Text style={styles.paragraph}>speed : {speed}</Text>
      <Text style={styles.paragraph}>mocked : {mocked}</Text>
      <Text style={styles.paragraph}>timestamp : {timestamp}</Text>
    </View>
   
  );
};

export default Test;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginLeft:10,
    justifyContent: "center",
    paddingTop: 10,
    backgroundColor: "#ecf0f1",
  },
  paragraph: {
    fontSize: 19,
    fontWeight:'bold'
  },
});
