import React from 'react'
import { StyleSheet, Text, View } from 'react-native'

const TrendingScreen = (props) => {
    return (
        <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
            <Text>Trending Screen</Text>
        </View>
    )
}

export default TrendingScreen

const styles = StyleSheet.create({})
