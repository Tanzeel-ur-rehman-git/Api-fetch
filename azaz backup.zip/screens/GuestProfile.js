import React from 'react'
import { StyleSheet, Text, View } from 'react-native'

const GuestProfile = (props) => {
    return (
        <View style={{flex:1, justifyContent:'center', alignItems:'center'}}>
            <Text>This is Guest Profile Screen</Text>
        </View>
    )
}

export default GuestProfile

const styles = StyleSheet.create({})
