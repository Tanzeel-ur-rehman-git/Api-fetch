import React,{useState, useEffect} from 'react'
import { Container, Header, Left, Body, Right, Button, Icon, Title ,Text} from 'native-base';
import { DrawerActions } from '@react-navigation/native';
import AsyncStorage from "@react-native-async-storage/async-storage";

const ReferFriendScreen = (props) => {

  const [userData, setUserData] = useState([]);

  const retrieveData = async () => {
    await AsyncStorage.getItem("@userData")
      .then((value) => {
        const user = JSON.parse(value);
        console.log(user)
        setUserData(user);
      })
      .catch((error) => {
        console.log(error);
      });
  };
 

  const usernumber = userData.phone;

  const refernumber = (usernumber / 40)* 3 - (78601 / 2);


useEffect(() => {
retrieveData();
return () => {
  
}
}, [])


    return (
        <Container>
        <Header >
          <Left style={{flexDirection:'row'}}>
          <Button transparent onPress={() => props.navigation.dispatch(DrawerActions.toggleDrawer())}>
            <Icon
            name="hamburger"
            type="FontAwesome5"
            style={{ fontSize: 35, color: "#ff6347" }}
          />
          </Button>
            <Button transparent onPress={()=> props.navigation.goBack()}>
              <Icon name='arrow-back' />
            </Button>

          </Left>
          <Body>
            <Title>Refer Friend</Title>
          </Body>
          <Right>
       
          </Right>
        </Header>
        <Body>
        <Text>You Refer Coad is : {parseInt(refernumber)}</Text>
        </Body>
      </Container>
    )
}

export default ReferFriendScreen

// const styles = StyleSheet.create({})
