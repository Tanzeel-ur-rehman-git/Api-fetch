import React from 'react'
import { StyleSheet, Text, View } from 'react-native'

const ProfileScreen = (props) => {
    return (
        <View style={styles.main1}>
            <Text>This is Profilescreen </Text>
        </View>
    )
}

export default ProfileScreen

const styles = StyleSheet.create({
    main1:{
        flex: 1,
        alignItems:'center',
        justifyContent:'center',
    }
})
