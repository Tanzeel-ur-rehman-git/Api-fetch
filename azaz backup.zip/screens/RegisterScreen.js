import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  Dimensions,
  TouchableOpacity,
  Alert,
  KeyboardAvoidingView,
} from "react-native";

import AsyncStorage from "@react-native-async-storage/async-storage";
import axios from "axios";


const RegisterScreen = (props) => {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");

    const register = async () => {
        await AsyncStorage.setItem("token", username);
        if (username != "" && password != "")
        axios.post('https://reqres.in/api/register', {
          email: username,
          password: password,
        })
          .then(function (response) {
            console.log(response.data);     
            props.navigation.navigate("Home");
          })
          .catch(function (error) {
            console.log(error);
            alert("invalid Username , Password");
          });
      else {
        alert("please fill username password");
      }

      };
    return (
        <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "position"}
        style={{ flex: 1, justifyContent: "center", top: 10 }}
        enabled
      >
        <View style={styles.main}>
          <Text>This is registration screen</Text>
          <TextInput
            placeholder="Enter username..."
            autoCapitalize="none"
            autoCorrect={false}
            underlineColorAndroid="transparent"
            placeholderTextColor="#999"
            returnKeyType="next"
            maxLength={256}
            style={styles.input}
            onChangeText={(value) => setUsername(value)}
          />
          <TextInput
            maxLength={40}
            placeholder="Enter password..."
            autoCapitalize="none"
            autoCorrect={false}
            returnKeyType="done"
            blurOnSubmit
            secureTextEntry
            underlineColorAndroid="transparent"
            placeholderTextColor="#999"
            style={styles.input}
            onChangeText={(value) => setPassword(value)}
          />
          <TouchableOpacity style={styles.but} onPress={register}>
            <Text style={{ fontWeight: "bold" }}>Register</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    )
}

export default RegisterScreen

const styles = StyleSheet.create({

    main: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
      },
      input: {
        width: Dimensions.get("window").width / 2 + 120,
        backgroundColor: "#e3e3e3",
        marginBottom: 20,
        height: 50,
        padding: 12,
        borderRadius: 6,
        shadowColor: "#000",
        shadowOffset: {
          width: 0,
          height: 4,
        },
        shadowOpacity: 0.05,
        shadowRadius: 4,
      },
      but: {
        width: "20%",
        height: 50,
        borderRadius: 20,
        backgroundColor: "yellow",
        shadowColor: "#000",
        borderWidth: 2,
        shadowOffset: {
          width: 0,
          height: 4,
        },
        shadowOpacity: 0.05,
        shadowRadius: 4,
        alignItems: "center",
        justifyContent: "center",
      },
})
