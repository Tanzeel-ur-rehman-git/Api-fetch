import React,{useState, useEffect} from 'react'
import { StyleSheet, Text, View,TouchableOpacity } from 'react-native'
import AsyncStorage from "@react-native-async-storage/async-storage";

const WelcomeScreen = (props) => {
    const [orignalLocation, setOrignalLocation] = useState(props.route.params.currentlatlong);
    const [Address, setAddress] = useState(props.route.params.currentAddress);
    const [userData, setUserData] = useState([]);

  // those global variable user in homescreen
    global.GoogleAddressText = Address.disLocation;
    global.CurrentLocationByExpo = orignalLocation;


    const retrieveData = async () => {
        await AsyncStorage.getItem("@userData")
          .then((value) => {
            const user = JSON.parse(value);
            console.log(user)
            setUserData(user);
          })
          .catch((error) => {
            console.log(error);
          });
      };



useEffect(() => {
    retrieveData();
    return () => {
      
    }
}, [])




    return (
        <View style={styles.main}>
             <Text>{userData.name}</Text>
            <Text>Current latitude : {orignalLocation.latitude}</Text>
            <Text>Current longitude : {orignalLocation.longitude}</Text>
            <Text>Current address is : {Address.disLocation}</Text>
            <Text>This is Welcome Screen</Text>
            <TouchableOpacity 
            onPress={()=>props.navigation.navigate("Home")
            }
            style={styles.but}
            >
            <Text>Home Screen</Text>
            </TouchableOpacity>
        </View>
    )
}

export default WelcomeScreen

const styles = StyleSheet.create({
    main:{
        flex:1,
        justifyContent:'center',
        alignItems:'center'
    },
    but: {
        width: "50%",
        height: 50,
        borderRadius: 20,
        backgroundColor: "yellow",
        shadowColor: "#000",
        borderWidth: 2,
        shadowOffset: {
          width: 0,
          height: 4,
        },
        shadowOpacity: 0.05,
        shadowRadius: 4,
        alignItems: "center",
        justifyContent: "center",
      }
})
