import React from 'react'
import { StyleSheet, View, Dimensions } from 'react-native'
import {Content, Left , ListItem, Thumbnail, Text, Body} from 'native-base'


const { width , height } = Dimensions.get("window");


const Searchscreen = (props) => {
    const {itemsearch} =props;
    console.log('itemsearch data',itemsearch)
    return (
        <Content style={{ width:width}}>
           {itemsearch.length > 0 ? (
                itemsearch.map((item) => (
                    <ListItem
                        key={item.id}
                        avatar
                    >
                        <Left>
                            <Thumbnail
                             source={item.avatar ? { uri: item.avatar } : null}
                            />
                        </Left>
                        <Body> 
                        <Text>{item.first_name}</Text>
                            <Text note>{item.email}</Text>
     

                        </Body>
                    </ListItem>
                   ))
                   
               ) 
               :(
                    <View style={{justifyContent:'center', alignItems:'center',height: 100}}>
                        <Text style={{alignSelf:'center'}}>No Product found</Text>
                    </View>
               )
            }
        </Content>
    )
}

export default Searchscreen

const styles = StyleSheet.create({})
