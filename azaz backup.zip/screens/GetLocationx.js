import React, { useEffect, useState, useRef } from "react";
import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  ActivityIndicator,
  TouchableOpacity,
  Alert,
  Button,
  Modal,
} from "react-native";
import MapView, { Marker, Circle } from "react-native-maps";
import * as Location from "expo-location";
import axios from "axios";
import { GooglePlacesAutocomplete } from "react-native-google-places-autocomplete";
import MaterialCommunityIcons from "react-native-vector-icons/MaterialCommunityIcons";

const { width, height } = Dimensions.get("window");

const GetLocationx = (props) => {
  const [location, setLocation] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);
  const [mapRegion, setMapRegion] = useState(null);
  const [googleMapRegion, setGoogleMapRegion] = useState(null);
  const [TouchableCheck, setTouchableCheck] = useState(true);
  const [modelShow, setModelShow] = useState(false);
  //   const [MyIdData, setMyIdData] = useState(props.route.params.userData1);
    // console.log(mapRegion.mocked);

  const getLocation = async () => {
    let { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== "granted") {
      setLocationMessage("Permission to access location was denied");
      return;
    }

    let location = await Location.getCurrentPositionAsync({});
    setLocation(location);
    setTouchableCheck(false);
    setMapRegion({
      longitude: location.coords.longitude,
      latitude: location.coords.latitude,
      //   longitudeDelta: 0.0922,
      //   latitudeDelta: 0.0421,
      longitudeDelta: 0.0255,
      latitudeDelta: 0.0255,
      mocked: location.mocked,
    });
    if(location.mocked == true)
      {
        setModelShow(true)
      }else{
        null
      }
  };

  const checkaddress = () => {
    if (googleMapRegion) {
      props.navigation.navigate("WelcomeScreen", {
        currentlatlong: mapRegion,
        currentAddress: googleMapRegion,
      });
    } else {
      Alert.alert("please search You location First");
    }
  };



  useEffect(() => {
    getLocation();
    return () => {
      setModelShow();
    };
  }, []);

  return (
    <View style={{ marginTop: 50, flex: 1 }}>
      <View>
        <Modal
          animationType={"slide"}
          transparent={false}
          visible={modelShow}
          // onRequestClose={() => {
          //   Alert.alert('Modal has now been closed.');
          // }}
        >
          <View
            style={{
              flex: 1,
              flexDirection: "column",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <View
              style={{
                width: 300,
                height: 300,
              }}
            >
              <Text>
                Chal mra Putr Chuti kr ta moke up location band kr ka a
              </Text>
            </View>
          </View>
        </Modal>
      </View>

      <GooglePlacesAutocomplete
        //   renderRightButton={() =>
        //        <TouchableOpacity
        //        onPress={()=>{getLocationbtn();}}
        //        style={{justifyContent:'center', backgroundColor:'pink'}}
        //        >
        //            <Text>Get Location</Text>
        //        </TouchableOpacity>

        // }

        renderLeftButton={() => (
          <MaterialCommunityIcons
            name="search-web"
            size={30}
            style={{
              position: "relative",
              zIndex: 1,
              left: 0,
              bottom: 0,
              top: 0,
              backgroundColor: "white",
            }}
          />
        )}
        enablePoweredByContainer={false}
        // currentLocation={true}
        // currentLocationLabel='Current location'
        placeholder="      Search here location By Street , City , Country"
        minLength={2} // minimum length of text to search
        autoFocus={true}
        fetchDetails={true}
        GooglePlacesSearchQuery={{
          rankby: "distance",
        }}
        onPress={(data, details = null) => {
          // 'details' is provided when fetchDetails = true
          //   console.log(data, details);
          setGoogleMapRegion({
            disLocation: data.description
              ? data.description
              : details.name + ", " + details.formatted_address,
            latitude: details.geometry.location.lat
              ? details.geometry.location.lat
              : data.geometry.location.lat,
            longitude: details.geometry.location.lng
              ? details.geometry.location.lng
              : data.geometry.location.lng,
            latitudeDelta: 0.0922,
            longitudeDelta: 0.0421,
          });
        }}
        query={{
          key: "AIzaSyDp88AnfIC2UfQI3KVqLK3M0Kqj487Z7wM",
          language: "en",
        }}
        styles={{
          container: {
            flex: 0,
            position: "absolute",
            width: "100%",
            zIndex: 1,
          },
          listView: { backgroundColor: "white" },
        }}
      />
      {googleMapRegion ? (
        <MapView
          initialRegion={googleMapRegion}
          mapType="terrain"
          style={styles.mapView}
          provider="google"
        >
          {googleMapRegion ? (
            <Marker
              coordinate={{
                longitude: googleMapRegion.longitude,
                latitude: googleMapRegion.latitude,
              }}
              title="Me"
              description="Myself"
            >
              {/* <View style={styles.circle}>
        <View style={styles.core} />
        <View style={styles.stroke} />
      </View> */}
            </Marker>
          ) : null}
        </MapView>
      ) : (
        <MapView
          initialRegion={mapRegion}
          mapType="terrain"
          style={styles.mapView}
          provider="google"
        >
          {mapRegion ? (
            <Marker
              coordinate={{
                longitude: mapRegion.longitude,
                latitude: mapRegion.latitude,
              }}
              title="Me"
              description="Myself"
            >
              {/* <View style={styles.circle}>
              <View style={styles.core} />
              <View style={styles.stroke} />
            </View> */}
            </Marker>
          ) : null}
        </MapView>
      )}

      <View
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          alignItems: "center",
        }}
      >
        <TouchableOpacity
          disabled={TouchableCheck}
          onPress={() => {
            checkaddress();
          }}
          style={styles.but}
        >
          <Text>Set Current Location</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  mapView: {
    width,
    height,
  },
  but: {
    width: "50%",
    height: 50,
    borderRadius: 20,
    backgroundColor: "yellow",
    shadowColor: "#000",
    borderWidth: 2,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    alignItems: "center",
    justifyContent: "center",
  },
});

export default GetLocationx;
