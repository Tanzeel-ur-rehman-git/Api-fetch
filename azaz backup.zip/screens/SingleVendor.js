import React, { useState, useEffect } from "react";
import { ScrollView, StyleSheet, Text, View,} from "react-native";
import {
  Container,
  Header,
  Left,
  Body,
  Right,
  Button,
  Icon,
  Title,
} from "native-base";
import { DrawerActions } from "@react-navigation/native";

//Screens
import ImageRender from "../Component/ImageRender";

const SingleVendor = (props) => {
  const [item, setItem] = useState(props.route.params.vitem);

  return (
    <Container>
      <Header>
        <Left style={{ flexDirection: "row" }}>
          <Button
            transparent
            onPress={() =>
              props.navigation.dispatch(DrawerActions.toggleDrawer())
            }
          >
            <Icon
              name="hamburger"
              type="FontAwesome5"
              style={{ fontSize: 35, color: "#ff6347" }}
            />
          </Button>
          <Button transparent onPress={() => props.navigation.goBack()}>
            <Icon name="arrow-back" />
          </Button>
        </Left>
        <Body>
          <Title>{item.business_name}</Title>
        </Body>
        <Right></Right>
      </Header>

      <View style={styles.upperscreen}>
      
        <View style={styles.image}>
          <ImageRender
            defaultImageSource={require("../assets/images/image-place-holder.png")}
            source={
              item.image
                ? {
                    uri:
                      "https://fattafatt.com/uploads/rest_image/" + item.image,
                  }
                : require("../assets/images/image-place-holder.png")
            }
          />
        </View>
            
        <View
          style={{ flex:1, justifyContent: "center", alignItems: "center" }}
        >
          <Text style={{ fontSize: 50, color: "white", shadowOpacity: 10 }}>
            {item.business_name}
          </Text>
          <View style={{ justifyContent: "center", alignItems: "center" }}>
            <Text style={{ fontSize: 20, color: "white", shadowOpacity: 10 }}>
              {item.description}
            </Text>
          </View>
          <View style={{ backgroundColor: "red", borderRadius: 50 }}>
            <Text style={{ fontSize: 20, color: "white", shadowOpacity: 10 }}>
              {item.rating}
            </Text>
          </View>
        </View>
       
      </View>
      
      <View style={styles.downscreen}></View>
      


    </Container>
  );
};

export default SingleVendor;

const styles = StyleSheet.create({
  upperscreen: {
    flex: 1,
    backgroundColor: "#e3e3e3",
  },
  downscreen: {
    flex: 2,
    backgroundColor: "#e3e3e3",
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
  },

  image: {
    height: "20%",
    width: "100%",
    top: 25,
  },
});
