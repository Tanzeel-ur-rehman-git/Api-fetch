import React, { useState, useEffect } from "react";
import { ScrollView, StyleSheet, Text, View, Image, TouchableOpacity,Dimensions,} from "react-native";
import {
  Button,
  Container,
  Header,
  Left,
  Body,
  Right,
  Icon,
  Title,
  ListItem,
  Thumbnail
} from "native-base";
import { DrawerActions } from "@react-navigation/native";
import axios from "axios";



const { width, height } = Dimensions.get("window");

//Redux call
import { connect } from 'react-redux'
import * as actions from '../redux/Actions/cartActions';

//Screen
import HomeSk from "../skelton/HomeSk";
import HeaderCartIcon from "../cart/HeaderCartIcon";

const SingleVendor = (props) => {
  const [item, setItem] = useState(props.route.params.vitem);
  const [vendorsProduct, setVendorsProduct] = useState([]);
  // const [TouchableCheck, setTouchableCheck] = useState(false);


  // const DisableTouchable =()=>{
  //   setTouchableCheck(true)
  // }

// console.log(item.id)
  const Vproduct = () => {
    const params =  new URLSearchParams( {
      ven_id: item.id
      }).toString();

      const url =
      "https://fattafatt.com/api/v1/user_actions.php?fetch_products=&" +
      params;

      axios.post(url, {
        headers: {
          'Content-Type': 'application/json',
        },
       })
        .then(function (response) {
          // console.log(response.data);     
            setVendorsProduct(response.data)
          }
        )
        .catch(function (error) {
          console.log(error);
        });
  };


  // const CheckAddItemtocart=(product)=>{
  //   const item_id = this.context.cart_items.findIndex(
  //     el => el.restaurant.id !== item.restaurant.id,
  //   );
  //   if (item_id === -1) {
  //     Alert.alert(
  //       'Added to basket',
  //       `${qty} ${item.name} was added to the basket.`,
  //     );
  //     this.context.addToCart(item, qty);
  //   } else {
  //     Alert.alert(
  //       'Cannot add to basket',
  //       'You can only order from one restaurant for each order.',
  //     );
  //   }
  // }

  useEffect(() => {
    Vproduct();
    return () => {
      setVendorsProduct();
    }
  }, [])

  return (
    <Container>
      <Header>
        <Left style={{ flexDirection: "row" }}>
          <Button transparent onPress={() =>{ 
            props.clearCart(),
            props.navigation.goBack()}}>
            <Icon name="arrow-back" />
          </Button>
        </Left>
        <Body>
          <Title>{item.business_name}</Title>
        </Body>
        <Right>
        <Button
            transparent
            onPress={() =>
              props.navigation.navigate('MainCart')
            }
          >
            <View>
            <Icon
              name="child-friendly"
              type="MaterialIcons"
              style={{ fontSize: 35, color: "#ff6347" }}
            />
            </View>
            <HeaderCartIcon />
          </Button>
        </Right>
      </Header>
        <ScrollView style={{flex:1}}>
          <View style={{flex:1}}>
          <Image
             resizeMode='cover'
            style={{height:130,}}
            source={
              item.image
                ? {
                    uri:
                      "https://fattafatt.com/uploads/rest_image/" + item.image,
                  }
                : require("../assets/images/image-place-holder.png")
            }
          />
          <View style={{justifyContent:'center'}}>
            <Text style={{alignSelf:'center'}}>Rating:  {parseFloat(item.rating).toFixed(1)}/5</Text>
          </View>
          </View>
          <View style={{flex:1}}>
          {vendorsProduct.length > 0 ? (
                vendorsProduct.map((vproduct) => (
                    <ListItem
                        key={vproduct.id}
                        avatar
                        style={{width:width}}
                    >
                        <Left>
                            <Thumbnail
                             source={vproduct.image ? { uri: "https://fattafatt.com/uploads/product_images/"+vproduct.image } : null}
                            />
                        </Left>
                        <Body> 
                        <TouchableOpacity 
                          // disabled={TouchableCheck}
                          onPress={()=>{
                            // DisableTouchable();
                            props.addItemToCart(vproduct);
                          }}
                        >
                        <Text>{vproduct.name}</Text>
                        <Text note>{vproduct.price}</Text>
                            </TouchableOpacity>
                          <Right>
                            <TouchableOpacity
                            // disabled={TouchableCheck}
                            onPress={()=>{
                              // DisableTouchable();
                              props.addItemToCart(vproduct);
                            }}
                            >
                            <Text>Add to cart</Text>
                            </TouchableOpacity>
                          </Right>
                        </Body>
                    </ListItem>
                    
                   ))
                   
               ) 
               :(
                    <View style={{justifyContent:'center', alignItems:'center',flex:1,height:height}}>
                        <HomeSk />
                    </View>
               )
            }
          </View>
        
        </ScrollView>
         
        
    </Container>
  );
};


const mapDispatchToProps = (dispatch) => {
    return {
          clearCart: () => dispatch(actions.clearCart()),
          addItemToCart: (product) => dispatch(actions.addToCart({quantity: 1, product}))    
    }
}

export default connect(null,mapDispatchToProps)(SingleVendor);

const styles = StyleSheet.create({

});
