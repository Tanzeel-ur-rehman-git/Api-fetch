import React, { useState, useEffect } from "react";
import {
  ScrollView,
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  Dimensions,
  Alert,
  FlatList
} from "react-native";
import {
  Button,
  Container,
  Header,
  Left,
  Body,
  Right,
  Icon,
  Title,
  ListItem,
  Thumbnail,
} from "native-base";
import axios from "axios";

const { width, height } = Dimensions.get("window");

//Redux call
import { useSelector, useDispatch } from "react-redux";
import * as actions from "../redux/Actions/cart";

//Screen
import HomeSk from "../skelton/HomeSk";
import HeaderCartIcon from "../cart/HeaderCartIcon";
import ProductItems from '../Component/ProductItems';

const SingleVendor = (props) => {
  const [item, setItem] = useState(props.route.params.vitem);
  const [vendorsProduct, setVendorsProduct] = useState([]);
  // const [TouchableCheck, setTouchableCheck] = useState(false);
  // console.log(item.id)
  // console.log(props.route.params)

  const dispatch = useDispatch();
  // const DisableTouchable =()=>{
  //   setTouchableCheck(true)
  // }

  const open_status = item.openStatus;

  const Vproduct = () => {
    const params = new URLSearchParams({
      ven_id: item.id,
    }).toString();

    const url =
      "https://fattafatt.com/api/v1/user_actions.php?fetch_products=&" + params;

    axios
      .post(url, {
        headers: {
          "Content-Type": "application/json",
        },
      })
      .then(function (response) {
        // console.log(response.data);
        setVendorsProduct(response.data);
      })
      .catch(function (error) {
        console.log(error);
      });
  };


   const checkCartx =  useSelector((state) => {
    if (state.cart.items){
    let x = Object.keys(state.cart.items);
    return x;
    }else{
      return 0
    }
  });
   const checkcart = ()=>{
    if (checkCartx.length > 0){
      Alert.alert(
              'Cart is Empty',
              'You can only order from one restaurant for each order.',
            );
    }
  }
  

  useEffect(() => {
    Vproduct();
    return () => {
      setVendorsProduct();
    };
  }, []);

  return (
    <Container>
      <Header>
        <Left style={{ flexDirection: "row" }}>
          <Button
            transparent
            onPress={() => {
              checkcart();
              props.navigation.goBack();
              dispatch(actions.clearCart())
              
            }}
          >
            <Icon name="arrow-back" />
          </Button>
        </Left>
        <Body>
          <Title>{item.business_name}</Title>
        </Body>
        <Right>
          <Button
            transparent
            onPress={() => props.navigation.navigate("MainCart")}
          >
            <View>
              <Icon
                name="child-friendly"
                type="MaterialIcons"
                style={{ fontSize: 35, color: "#ff6347" }}
              />
            </View>
            <HeaderCartIcon />
          </Button>
        </Right>
      </Header>


        <View>
          <Image
            resizeMode="cover"
            style={{ height: 130 }}
            source={
              item.image
                ? {
                    uri:
                      "https://fattafatt.com/uploads/rest_image/" + item.image,
                  }
                : require("../assets/images/image-place-holder.png")
            }
          />
          <View style={{ justifyContent: "center" }}>
            <Text style={{ alignSelf: "center" }}>
              Rating: {parseFloat(item.rating).toFixed(1)}/5
            </Text>
            {open_status == '0' ? (<View style={{backgroundColor:'red',justifyContent:'center',alignItems:'center', height:30}}><Text style={{color:'white',fontWeight:'bold'}}>Closed</Text></View>):(null)}
          </View>
        </View>
        <View>
      </View>
      <View style={{ flex: 1}}>
      {vendorsProduct.length ? (
           <FlatList
           data={vendorsProduct}
           showsVerticalScrollIndicator={false}
           keyExtractor={(item, index) => "key" + index}
           renderItem={({ item }) => {
            return (
            <ProductItems
            item={item}
            open_status={open_status}
            />
            )
          }}
          />
      ):(
        <View
              style={{
                justifyContent: "center",
                alignItems: "center",
                flex: 1,
                height: height,
              }}
            >
              <HomeSk />
            </View>
      )} 
      </View>
    </Container>
  );
};

export default SingleVendor;

const styles = StyleSheet.create({});
