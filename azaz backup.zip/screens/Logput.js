import React from 'react';
import { StyleSheet, Text, View,SafeAreaView ,Dimensions} from 'react-native';
import { TouchableOpacity } from "react-native-gesture-handler";
import AsyncStorage from "@react-native-async-storage/async-storage";

const { width, height } = Dimensions.get("window");



const Logput = (props) => {
    const logout = async () => {
        await AsyncStorage.removeItem("token");
        props.navigation.navigate("Login");
      }; 
    return (
        <SafeAreaView>
             <View
            style={{
              backgroundColor: "green",
              width: width,
              alignItems: "center",
            }}
          >
            <TouchableOpacity onPress={logout} style={styles.but}>
              <Text style={{ fontWeight: "bold" }}>Logout</Text>
            </TouchableOpacity>
          </View>
        </SafeAreaView>
    )
}

export default Logput

const styles = StyleSheet.create({
    but: {
        width: 300,
        height: 50,
        borderRadius: 20,
        backgroundColor: "yellow",
        shadowColor: "#000",
        borderWidth: 2,
        shadowOffset: {
          width: 0,
          height: 4,
        },
        shadowOpacity: 0.05,
        shadowRadius: 4,
        alignItems: "center",
        justifyContent: "center",
      },
})
