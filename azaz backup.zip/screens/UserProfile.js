import React,{useState, useEffect} from 'react'
import { Container, Header, Left, Body, Right, Button, Icon, Title ,Text} from 'native-base';
import { DrawerActions } from '@react-navigation/native';
import AsyncStorage from "@react-native-async-storage/async-storage";


const UserProfile = (props) => {
const [userData, setUserData] = useState([]);

  const retrieveData = async () => {
    await AsyncStorage.getItem("@userData")
      .then((value) => {
        const user = JSON.parse(value);
        console.log(user)
        setUserData(user);
      })
      .catch((error) => {
        console.log(error);
      });
  };



useEffect(() => {
retrieveData();
return () => {
  
}
}, [])

  
    return (
        <Container>
        <Header >
          <Left style={{flexDirection:'row'}}>
          <Button transparent onPress={() => props.navigation.dispatch(DrawerActions.toggleDrawer())}>
            <Icon
            name="hamburger"
            type="FontAwesome5"
            style={{ fontSize: 35, color: "#ff6347" }}
          />
          </Button>
            <Button transparent onPress={()=> props.navigation.goBack()}>
              <Icon name='arrow-back' />
            </Button>

          </Left>
          <Body>
            <Title>User Profile</Title>
          </Body>
          <Right>
       
          </Right>
        </Header>
        <Body>
        <Text>ID : {userData.id}</Text>
        <Text>Name : {userData.name}</Text>
        <Text>City ID : {userData.city}</Text>
        <Text>Email : {userData.email}</Text>
        <Text>password : {userData.password}</Text>
        <Text>phone : {userData.phone}</Text>
        <Text>Date of birth : {userData.DOB}</Text>
        <Text>Status : {userData.status}</Text>
        <Text>Date of creation : {userData.timestamp}</Text>

        </Body>
      </Container>
    )
}

export default UserProfile

// const styles = StyleSheet.create({})
