import React from 'react'
import { StyleSheet, Text, View } from 'react-native'

const UserProfile = (props) => {
    return (
        <View style={{flex:1, justifyContent:'center', alignItems:'center'}}>
            <Text>This is User profile</Text>
        </View>
    )
}

export default UserProfile

const styles = StyleSheet.create({})
