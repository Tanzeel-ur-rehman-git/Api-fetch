import axios from "axios";
import React, { useState, useEffect } from "react";
import {
  Button,
  StyleSheet,
  View,
  FlatList,
  Image,
  Dimensions,
} from "react-native";
import { Header, Container, Icon, Item, Input, Text } from "native-base";
import AsyncStorage from "@react-native-async-storage/async-storage";



const { width, height } = Dimensions.get("window");


//Screens
import Card from "../Component/Card";
import HeaderScreen from "../Component/Header";
import Searchscreen from './Searchscreen';
import { TouchableOpacity } from "react-native-gesture-handler";



const HomeScreen = (props) => {
  const [data, setData] = useState([]);
  const [itemsearch, setItemsearch] = useState([]);
  const [focus, setFocus] = useState();

  useEffect(() => {
    getDataFromAPI();
    return () => {
      setData([]);
      setItemsearch([]);
      setFocus();
    };
  }, []);


  function getDataFromAPI() {
    axios
      .get("https://fattafatt.com/api/v1/user_actions.php?all_vendor=%27%27&city=1")
      .then(async function (response) {
        setData(response.data);
        setItemsearch(response.data);
        setFocus(false)
      })
      .catch(function (error) {
        console.log(error);
      });
  }

  if (!data) {
    return null;
  };

  const logout = async () => {
    await AsyncStorage.removeItem("token");
    props.navigation.navigate("Login");
  };

  const onb = async () => {
    await AsyncStorage.removeItem("onboard");
  };

const searchitem =(text)=>{
  setItemsearch(
    data.filter((i) => i.business_name.toLowerCase().includes(text.toLowerCase()))
  );

}
const openlist= ()=>{
  setFocus(true);
}

const onblur=()=>{
  setFocus(false);
}


  

  return (
    <Container>
      <HeaderScreen />
      <Header searchBar rounded>
        <Item>
          <Icon name="ios-search" />
          <Input
          placeholder="search"
          onFocus={openlist}
          onChangeText={(text)=> searchitem(text)}
          />
        </Item>
      </Header>
      {focus==true ?(
        <View style={{flex:1}}>
            <Searchscreen
            itemsearch={itemsearch}
            />
        </View>

      ):(
        <View style={styles.main2}>
        <View style={{ flex: 1 }}>
          <FlatList
            numColumns={2}
            data={data}
            keyExtractor={(item, index) => "key" + index}
            renderItem={({ item }) => {
              return <Card item={item} />;
            }}
          />
        </View>
        <View style={{backgroundColor:'green', width:width, alignItems:'center'}}>
            <TouchableOpacity
            onPress={logout} 
            style={styles.but}
            >
              <Text style={{ fontWeight: "bold" }} >Logout</Text>
            </TouchableOpacity>
        </View>
        <View style={{backgroundColor:'green', width:width, alignItems:'center'}}>
            <TouchableOpacity
            onPress={onb} 
            style={styles.but}
            >
              <Text style={{ fontWeight: "bold" }} >fresh on boarding</Text>
            </TouchableOpacity>
        </View>
      </View>
      )}
  
    </Container>

  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  main2: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  image: {
    height: "100%",
    resizeMode: "contain",
  },
  but: {
    width: 300,
    height: 50,
    borderRadius: 20,
    backgroundColor: "yellow",
    shadowColor: "#000",
    borderWidth: 2,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    alignItems: "center",
    justifyContent: "center",
  },
});
