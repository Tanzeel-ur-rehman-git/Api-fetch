import axios from "axios";
import React, { useState, useEffect } from "react";
import { StyleSheet, View, FlatList, Dimensions } from "react-native";
import { Header, Container, Icon, Item, Input, Text } from "native-base";
// import { bindActionCreators } from 'redux';
// import { connect } from 'react-redux';

const { width, height } = Dimensions.get("window");

//Redux Data
// import {FetchVendorAction} from '../redux/Actions/FetchVendorAction';


//Screens
import Card from "../Component/Card";
import Searchscreen from "./Searchscreen";
import Swiperbanner from "../Component/Swiperbanner";
import CategoryFilter from "./CategoryFilter";

//skelton
import HomeSk from "../skelton/HomeSk";
import { TouchableOpacity } from "react-native-gesture-handler";

const HomeScreen = (props) => {
  const [vendors, setVendors] = useState([]);
  const [categories, setCategories] = useState([]);
  const [itemsearch, setItemsearch] = useState([]);
  const [focus, setFocus] = useState();
  const [isLoading, setIsLoading] = useState(true);
  const [active, setActive] = useState();
  const [initialState, setInitialState] = useState([]);
  const [productsCtg, setProductsCtg] = useState([]);

  useEffect(() => {
    // props.FetchVendorAction();
    getVendorsFromAPI();
    getcategoriesFromAPI();
    return () => {
      setVendors([]);
      setItemsearch([]);
      setFocus();
      setCategories([]);
      setCategories([]);
      setActive();
      setInitialState([]);
    };
  }, []);

  function getcategoriesFromAPI() {
    axios
      .get("https://fattafatt.com/api/v1/user-ff-31.php?catfetch&catId=36")
      .then(async function (response) {
        setCategories(response.data);
        setActive(-1);
      })
      .catch(function (error) {
        console.log(error);
      });
  }

  if (!categories) {
    return null;
  }

  function getVendorsFromAPI() {
    axios
      .get(
        "https://fattafatt.com/api/v1/user_actions.php?all_vendor=%27%27&city=1"
      )
      .then(async function (response) {
        setVendors(response.data);
        setItemsearch(response.data);
        setFocus(false);
        setIsLoading(false);
        setProductsCtg(response.data);
        setInitialState(response.data);
      })
      .catch(function (error) {
        console.log(error);
      });
  }

  if (!vendors) {
    return null;
  }

  // const onb = async () => {
  //   await AsyncStorage.removeItem("onboard");
  // };


  //redux function
  // const { VendorsReducers} = props.VendorsReducers
  // console.log(VendorsReducers);


  const searchitem = (text) => {
    setItemsearch(
      vendors.filter((i) =>
        i.business_name.toLowerCase().includes(text.toLowerCase())
      )
    );
  };
  const openSearch = () => {
    setFocus(true);
  };

  const closeSearch = () => {
    setFocus(false);
  };

  const changeCtg = (ctg) => {
    {
      ctg === "all"
        ? [setProductsCtg(initialState), setActive(true)]
        : [
            setProductsCtg(
              vendors.filter((i) => i.business_type_cat === ctg),
              setActive(true)
            ),
          ];
    }
  };

  return (
    <Container>
      <View
        style={{
          height: 60,
          width: "100%",
          flexDirection: "row",
          top: 25,
          left: 15,
        }}
      >
        <View style={{ flex: 1 }}>
          <Icon
            name="hamburger"
            type="FontAwesome5"
            style={{ fontSize: 35, color: "#ff6347" }}
            onPress={() => props.navigation.toggleDrawer()}
          />
        </View>
        <View style={{ flex: 4, backgroundColor: "green" }}></View>
        <View style={{ flex: 1 }}>
          <Icon
            name="settings"
            type="Octicons"
            style={{ fontSize: 35, color: "black", left: 3 }}
            onPress={() => props.navigation.toggleDrawer()}
          />
        </View>
      </View>

      <Header searchBar rounded>
        <Item>
          <Icon name="ios-search" />
          <Input
            placeholder="search"
            onFocus={openSearch}
            onChangeText={(text) => searchitem(text)}
          />
          {focus == true ? (
            <Icon onPress={closeSearch} name="ios-close" />
          ) : null}
        </Item>
      </Header>
      {focus == true ? (
        <View style={{ flex: 1 }}>
          
          <Searchscreen 
          navigation={props.navigation}
          itemsearch={itemsearch} />
        </View>
      ) : (
        <View style={styles.main2}>
          <Swiperbanner />
          <View style={{ height: 40, width: width }}>
            <CategoryFilter
              categories={categories}
              active={active}
              setActive={setActive}
              categoryFilter={changeCtg}
              productsCtg={productsCtg}
            />
          </View>

          {productsCtg.length > 0 ? (
            <View style={{ flex: 1 }}>
              <FlatList
                numColumns={2}
                data={productsCtg}
                showsVerticalScrollIndicator={false}
                keyExtractor={(item, index) => "key" + index}
                renderItem={({ item }) => {
                  return (
                  <TouchableOpacity  onPress={()=> {props.navigation.navigate('SingleVendor',{vitem:item})}} >
                  <Card 
                  item={item}
                  navigation={props.navigation} />
                  </TouchableOpacity>
                  )
                }}
                 // Performance settings
                removeClippedSubviews={true} // Unmount components when outside of window 
                initialNumToRender={2} // Reduce initial render amount
                maxToRenderPerBatch={1} // Reduce number in each render batch
                updateCellsBatchingPeriod={100} // Increase time between renders
                windowSize={7} // Reduce the window size
                onEndReachedThreshold={0.7}
                bounces={false}
              />
            </View>
          ) : (
            <View style={[styles.center, { height: height / 2 }]}>
              {isLoading ? (
                <View>
                  <HomeSk />
                </View>
              ) : (
                <View></View>
              )}
              <Text>No products found</Text>
            </View>
          )}

          {/* <View style={{backgroundColor:'green', width:width, alignItems:'center'}}>
            <TouchableOpacity
            onPress={onb} 
            style={styles.but}
            >
              <Text style={{ fontWeight: "bold" }} >fresh on boarding</Text>
            </TouchableOpacity>
        </View> */}
        </View>
      )}
    </Container>
  );
};

// function mapStateToProps(state) {
//   const {VendorsReducers} = state;
//   return {
//     VendorsReducers: VendorsReducers,
//   }
// }

// function mapDispatchToProps(dispatch) {
//   return {
//       ...bindActionCreators({ FetchVendorAction }, dispatch)
//   }
// }

// export default connect(mapStateToProps, mapDispatchToProps)(HomeScreen);

export default HomeScreen;

const styles = StyleSheet.create({
  main2: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  image: {
    height: "100%",
    resizeMode: "contain",
  },
  but: {
    width: 300,
    height: 50,
    borderRadius: 20,
    backgroundColor: "yellow",
    shadowColor: "#000",
    borderWidth: 2,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    alignItems: "center",
    justifyContent: "center",
  },
});

//Ruff Code
{
  /* {isLoading ? (
            <HomeSk />
          ) : (
            <View style={{ flex: 1 }}>
              <FlatList
                numColumns={2}
                data={vendors}
                keyExtractor={(item, index) => "key" + index}
                renderItem={({ item }) => {
                  return <Card item={item} />;
                }}
                initialNumToRender={7}
                maxToRenderPerBatch={7}
              />
            </View>
          )}  */
}

{
  /* {
            (() => {
              if (productsCtg.length > 0 || isLoading == true)
              return <HomeSk />
              else if (isLoading == false)
                 return  <View style={{ flex: 1 }}>
                 <FlatList
                   numColumns={2}
                   data={productsCtg}
                   keyExtractor={(item, index) => "key" + index}
                   renderItem={({ item }) => {
                     return <Card item={item} />;
                   }}
                   initialNumToRender={7}
                   maxToRenderPerBatch={7}
                 />
               </View>
               else(productsCtg.length < 0)
                 return  <View style={[styles.center, { height: height / 2 }]}>
                 <Text>No products found</Text>
               </View>
               
          })()
          } */
}
