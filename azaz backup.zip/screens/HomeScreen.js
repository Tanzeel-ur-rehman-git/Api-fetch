import axios from "axios";
import React, { useState, useEffect } from "react";
import {
  Button,
  StyleSheet,
  View,
  FlatList,
  Image,
  Dimensions,
} from "react-native";
const { width, height } = Dimensions.get("window");
import Card from "../Component/Card";
import HeaderScreen from "../Component/Header";
import Footer from "../Component/Footer";
import { Header, Container, Icon, Item, Input, Text } from "native-base";
import Searchscreen from './Searchscreen';

const HomeScreen = (props) => {
  const [data, setData] = useState([]);
  const [itemsearch, setItemsearch] = useState([]);
  const [focus, setFocus] = useState();

  useEffect(() => {
    getDataFromAPI();
    return () => {
      setData([]);
      setItemsearch([]);
      setFocus();
    };
  }, []);


  function getDataFromAPI() {
    axios
      .get("https://reqres.in/api/users?page=2")
      .then(async function (response) {
        setData(response.data);
        setItemsearch(response.data);
        setFocus(false)
      })
      .catch(function (error) {
        console.log(error);
      });
  }

  if (!data) {
    return null;
  }

const searchitem =(text)=>{
  setItemsearch(
    data.data.filter((i) => i.first_name.toLowerCase().includes(text.toLowerCase()))
  );

}
const openlist= ()=>{
  setFocus(true);
}

const onblur=()=>{
  setFocus(false);
}


  

  return (
    <Container>
      <HeaderScreen />
      <Header searchBar rounded>
        <Item>
          <Icon name="ios-search" />
          <Input
          placeholder="search"
          onFocus={openlist}
          onChangeText={(text)=> searchitem(text)}
          />
        </Item>
      </Header>
      {focus==true ?(
        <View style={{flex:1}}>
            <Searchscreen
            itemsearch={itemsearch}
            />
        </View>

      ):(
        <View style={styles.main2}>
        <View style={{ flex: 1 }}>
          <FlatList
            numColumns={2}
            data={data.data}
            keyExtractor={(item, index) => "key" + index}
            renderItem={({ item }) => {
              return <Card item={item} />;
            }}
          />
        </View>
        <Footer />
        <Button
        onPress={()=> {props.navigation.navigate('Search')}}
        title='azaz'
        />
      </View>
      )}
  
    </Container>

  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  main2: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  image: {
    height: "100%",
    resizeMode: "contain",
  },
});
