import React, { Component } from 'react';
import { Container, Header, Left, Body, Right, Button, Icon, Title ,Text} from 'native-base';
import { DrawerActions } from '@react-navigation/native';

const PrivacyPolicy = (props) => {
    return (
        <Container>
        <Header >
          <Left style={{flexDirection:'row'}}>
          <Button transparent onPress={() => props.navigation.dispatch(DrawerActions.toggleDrawer())}>
            <Icon
            name="hamburger"
            type="FontAwesome5"
            style={{ fontSize: 35, color: "#ff6347" }}
          />
          </Button>
            <Button transparent onPress={()=> props.navigation.goBack()}>
              <Icon name='arrow-back' />
            </Button>

          </Left>
          <Body>
            <Title>Privacy Policy</Title>
          </Body>
          <Right>
       
          </Right>
        </Header>
        <Body>
        <Text>This is Privacy Policy</Text>
        </Body>
      </Container>
    )
}

export default PrivacyPolicy
