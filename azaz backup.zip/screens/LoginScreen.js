import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  Dimensions,
  TouchableOpacity,
  Alert,
  KeyboardAvoidingView,
} from "react-native";


import AsyncStorage from "@react-native-async-storage/async-storage";
import axios from "axios";

const LoginScreen = (props) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  // const [token, setToken] = useState(null);

  const Userlogin = async () => {
    await AsyncStorage.setItem("token", username);
    // if (username != "" && password != ""){
    const params =  new URLSearchParams( {
      email: '03216299194',  //username
      password: 'awi1', //password
      }).toString();

      const url =
      "https://fattafatt.com/ffunderdog/xyz66678889089.php?" +
      params;

      axios.post(url, {
        headers: {
          'Content-Type': 'application/json',
        },
       })
        .then(function (response) {
          // console.log(response.data);     
          if(response.data === 0)
          {
            alert('invalid login')
          } else{
            props.navigation.replace("Home");
          }
        })
        .catch(function (error) {
          console.log(error);
          alert("invalid Username , Password");
        });
    //   }else {
    //   alert("please fill username password");
    // }
  };

// Code need to modify error is => is use press delete if make in home
  // const tokenlogin = async () => {
  //   const value = await AsyncStorage.getItem("token");
  //   if (value !== null) {
  //     props.navigation.navigate("Home");
  //   } else {
  //     return null;
  //   }
  // };

  // tokenlogin();

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "position"}
      style={{ flex: 1, justifyContent: "center", top: 10 }}
      enabled
    >
      <View style={styles.main}>
        <Text>This is Login screen</Text>
        <TextInput
          placeholder="03xx0000000"
          autoCapitalize="none"
          autoCorrect={false}
          underlineColorAndroid="transparent"
          placeholderTextColor="#999"
          returnKeyType="next"
          keyboardType="number-pad"
          maxLength={11}
          style={styles.input}
          onChangeText={(value) => setUsername(value)}
        />
        <TextInput
          maxLength={40}
          placeholder="Enter password..."
          autoCapitalize="none"
          autoCorrect={false}
          returnKeyType="done"
          blurOnSubmit
          secureTextEntry
          underlineColorAndroid="transparent"
          placeholderTextColor="#999"
          style={styles.input}
          onChangeText={(value) => setPassword(value)}
        />
        <TouchableOpacity style={styles.but} onPress={Userlogin}>
          <Text style={{ fontWeight: "bold" }}>Login</Text>
        </TouchableOpacity>
        <View style={{flexDirection:'row', top:15,}}>
          <Text>Dont have account?</Text>
          <TouchableOpacity onPress={()=> props.navigation.navigate('Register')}>
            <Text style={styles.registerd}>Register Here</Text>
          </TouchableOpacity>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
};

export default LoginScreen;

const styles = StyleSheet.create({
  main: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  input: {
    width: Dimensions.get("window").width / 2 + 120,
    backgroundColor: "#e3e3e3",
    marginBottom: 20,
    height: 50,
    padding: 12,
    borderRadius: 6,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.05,
    shadowRadius: 4,
  },
  but: {
    width: "20%",
    height: 50,
    borderRadius: 20,
    backgroundColor: "yellow",
    shadowColor: "#000",
    borderWidth: 2,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    alignItems: "center",
    justifyContent: "center",
  },
  registerd:{
    fontWeight:'bold',
    color:'blue',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.5,
    shadowColor: "#000",

  }
});




// Raw data for node js api post
//
// const login = async () => {
//   await AsyncStorage.setItem("token", username);
//   if (username != "" && password != "")
//     axios.post('https://reqres.in/api/login', {
//       email: username,
//       password: password,
//     })
//       .then(function (response) {
//         console.log(response.data);     
//         props.navigation.replace("Home");
//       })
//       .catch(function (error) {
//         console.log(error);
//         alert("invalid Username , Password");
//       });
//   else {
//     alert("please fill username password");
//   }
// };