import React from 'react'
import { Dimensions, StyleSheet, View, Image,Button,ImageBackground,Text } from 'react-native';
import AsyncStorage from "@react-native-async-storage/async-storage";


const Footer = (props) => {
    // console.log(props)s
    const logout = async () => {
        await AsyncStorage.removeItem("token");
        props.navigation.navigate("Login");
      };

    return (
        <View style={styles.headermain}>
        {/* <ImageBackground
        style={styles.imageheader}
        source={{ uri: 'https://thecolorrun.ae/wp-content/uploads/2018-default-page-header.jpg'}}>

        </ImageBackground> */}
            <Text style={{alignSelf:'center'}}>This is home screen</Text>
      <Button title="click me" onPress={logout} />
        </View>
    )
}

export default Footer

const styles = StyleSheet.create({
    headermain:{
        width:Dimensions.get("window").width,
        height:50,
        backgroundColor:'#e3e3e3',
        borderTopRightRadius: 20,
        borderTopLeftRadius:20,
        shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    },
    imageheader:{
        resizeMode:'stretch',
        height:50,
        borderBottomRightRadius: 20,
        borderBottomLeftRadius:20,
    }
})
