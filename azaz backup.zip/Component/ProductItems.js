import React, { useState, useEffect } from "react";
import {
  ScrollView,
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  Dimensions,
  Alert,
  FlatList,
} from "react-native";
import {
  Button,
  Container,
  Header,
  Left,
  Body,
  Right,
  Icon,
  Title,
  ListItem,
  Thumbnail,
} from "native-base";

import * as actions from "../redux/Actions/cart";
import { useDispatch } from "react-redux";
const { width, height } = Dimensions.get("window");

//Screens

const Card = (props) => {
  const { item } = props;
  const dispatch = useDispatch();
  // console.log(props.navigation)
  return (
    <ListItem key={item.id} avatar style={styles.listItem}>
      {props.open_status == "0" ? (
        <Left>
          <Thumbnail style={{opacity:0.4}}
            source={
              item.image
                ? {
                    uri:
                      "https://fattafatt.com/uploads/product_images/" +
                      item.image,
                  }
                : null
            }
          />
        </Left>
      ) : (
        <Left>
          <Thumbnail
            source={
              item.image
                ? {
                    uri:
                      "https://fattafatt.com/uploads/product_images/" +
                      item.image,
                  }
                : null
            }
          />
        </Left>
      )}

      {props.open_status == "0" ? (
        <Body style={styles.bodyclosed}>
          <TouchableOpacity
            // disabled={TouchableCheck}
            onPress={() => {  }}
          >
            <Left>
              <Text>{item.name}</Text>
            </Left>
            <Body style={styles.body}>
              <Left>
                <Text note>{item.price}</Text>
              </Left>
            </Body>
          </TouchableOpacity>
          <Right>
            <TouchableOpacity
              // disabled={TouchableCheck}
              onPress={() => {}}
            >
              <Text>Add </Text>
            </TouchableOpacity>
          </Right>
        </Body>
      ) : (
        <Body style={styles.body}>
          <TouchableOpacity
            // disabled={TouchableCheck}
            onPress={() => {
              // DisableTouchable();
              dispatch(
                actions.addToCart({
                  id: item.id,
                  productTitle: item.name,
                  productPrice: parseInt(item.price),
                })
              );
            }}
          >
            <Left>
              <Text>{item.name}</Text>
            </Left>
            <Body style={styles.body}>
              <Left>
                <Text note>{item.price}</Text>
              </Left>
            </Body>
          </TouchableOpacity>
          <Right>
            <TouchableOpacity
              // disabled={TouchableCheck}
              onPress={() => {
                // DisableTouchable();
                dispatch(
                  actions.addToCart({
                    id: item.id,
                    productTitle: item.name,
                    productPrice: parseInt(item.price),
                  })
                );
              }}
            >
              <Text>Add </Text>
            </TouchableOpacity>
          </Right>
        </Body>
      )}
    </ListItem>
  );
};

export default Card;

const styles = StyleSheet.create({
  listItem: {
    alignItems: "center",
    backgroundColor: "white",
    justifyContent: "center",
  },
  body: {
    margin: 10,
    alignItems: "center",
    flexDirection: "row",
  },
  bodyclosed: {
    margin: 10,
    alignItems: "center",
    flexDirection: "row",
    opacity: 0.4,
  },
});
