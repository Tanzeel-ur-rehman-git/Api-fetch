import React from 'react'
import { Dimensions, StyleSheet, Text, View, Image } from 'react-native'

const Header = () => {
    return (
        <View style={styles.headermain}>
             <Image
        style={styles.imageheader}
        source={{ uri: 'https://thecolorrun.ae/wp-content/uploads/2018-default-page-header.jpg'}}
      />
            
        </View>
    )
}

export default Header

const styles = StyleSheet.create({
    headermain:{
        width:Dimensions.get("window").width,
        height:50,
        backgroundColor:'black',
        borderBottomRightRadius: 20,
        borderBottomLeftRadius:20,
        shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    },
    imageheader:{
        resizeMode:'stretch',
        height:50,
        borderBottomRightRadius: 20,
        borderBottomLeftRadius:20,
    }
})
