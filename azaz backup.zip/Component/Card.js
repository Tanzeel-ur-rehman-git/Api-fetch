import React from "react";
import { View, StyleSheet, Text, Image, Dimensions } from "react-native";

const { width, height } = Dimensions.get("window");

//Screens
import ImageRender from '../Component/ImageRender';


const Card = ({ item }) => {
  // console.log(item)
  return (
    <View style={styles.cardView}>
    <ImageRender 
    defaultImageSource={require('../assets/images/image-place-holder.png')}
    source={item.image ? { uri: "https://fattafatt.com/uploads/rest_image/"+item.image } : require('../assets/images/image-place-holder.png')}
    style={styles.image}
    resizeMode="cover"
    />
      <Text>{item.business_name}</Text>
      <Text>{item.owner_phone}</Text>
      <Text>{item.address}</Text>
    </View>
  );
};

export default Card;

const styles = StyleSheet.create({
  cardView: {
    backgroundColor: "white",
    margin: width * 0.03,
    borderRadius: width * 0.05,
    shadowColor: "#000",
    shadowOffset: { width: 0.5, height: 0.5 },
    shadowOpacity: 0.5,
    shadowRadius: 3,
    height:width /2 +20,
    width:width/2 -30
  },
  title: {
    marginHorizontal: width * 0.05,
    marginVertical: width * 0.03,
    color: "black",
    fontSize: 20,
    fontWeight: "bold",
  },
  description: {
    marginVertical: width * 0.05,
    marginHorizontal: width * 0.02,
    color: "gray",
    fontSize: 18,
  },
  image: {
    height: height / 7,
    marginLeft: width * 0.05,
    marginRight: width * 0.05,
    marginVertical: height * 0.02,
    top:-25,
    shadowColor: "#000",
    shadowOffset: { width: 0.5, height: 0.5 },
    shadowOpacity: 1,
    shadowRadius: 3,
    borderRadius:20,
    borderColor: 'black',
    borderWidth: 2,
    width:width/3


  },
  author: {
    marginBottom: width * 0.0,
    marginHorizontal: width * 0.05,
    fontSize: 15,
    color: "gray",
  },
});
