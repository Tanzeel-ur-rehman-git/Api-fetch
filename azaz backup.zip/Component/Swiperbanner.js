import React, { useState, useEffect } from "react";
import { Image, StyleSheet, Dimensions, View, ScrollView, Linking } from "react-native";
import Swiper from "react-native-swiper/src";
import axios from "axios";
import { TouchableOpacity } from "react-native-gesture-handler";

// import Swiper, { Autoplay} from 'swiper';
// Swiper.use([Autoplay]);

var { width,height } = Dimensions.get("window");

const Swiperbanner = () => {

  const [data, setData] = useState([]);

  useEffect(() => {
    getDataFromAPI();
   
    return () => {
      setData([]);
    };
  }, []);


  function getDataFromAPI() {
    axios.get("https://fattafatt.com/api/fattafatt_v2/v1/user_actions.php?fetch_ads=1")
      .then(async function (response) {
        setData(response.data);
      })
      .catch(function (error) {
        console.log(error);
      });
  }

  if (!data) {
    return null;
  };

  return (
    <View style={{height:200,}}>
    <ScrollView>
      <View  style={styles.container}>
        <View  style={styles.swiper}>
          <Swiper
            style={{ height: width / 2 }}
            showButtons={false}
            autoplay={true}
            autoplayTimeout = {2.5}
            key={data.length}
          >
            {data.map((item) => {
              return (
                <TouchableOpacity
                key = {item.id}
                onPress={()=> Linking.openURL(item.url)}
                >
                  <Image
                    key={item.id}
                    style={styles.imageBanner}
                    resizeMode="cover"
                    source={item.image ? { uri: "https://fattafatt.com/uploads/advertisements/"+item.image } : require('../assets/images/image-place-holder.png')}
                  />
                </TouchableOpacity>
              );
            })}
          </Swiper>
          <View style={{ height: 20 }}></View>
        </View>
      </View>
    </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    
    // height:0,
    // backgroundColor:'black',
  },
  swiper: {
    width: width,
    alignItems: "center",
    marginTop: 10,
    
    

  },
  imageBanner: {
    height: width / 2-40,
    width: width -30,
    borderRadius: 10,
    marginHorizontal: 20,
    backgroundColor:'red',
  },
});

export default Swiperbanner;
