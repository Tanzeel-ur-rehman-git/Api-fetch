import React from 'react';
import {View, StyleSheet, Animated, Dimensions} from 'react-native';

const { width, height } = Dimensions.get("window");

class ImageRender extends React.Component {
  imageAnimated = new Animated.Value(0);


  handleImageLoad = () => {
    Animated.timing(this.imageAnimated, {
      toValue: 1,
      duration: 1000,
      useNativeDriver: true,
    }).start();
  };

  render() {
    const {defaultImageSource, source, style, ...props} = this.props;
    return (
      <View style={styles.container}>
           <Animated.Image
          {...props}
          source={defaultImageSource}
          style={style }
        />
        <Animated.Image
          {...props}
          source={source}
          style={[style, {opacity: this.imageAnimated}, styles.imageOverlay]}
          onLoad={this.handleImageLoad}
         
        />
      </View>
    );
  }
}

export default ImageRender;

const styles = StyleSheet.create({
  container: {
    // backgroundColor: 'black',
  },
  imageOverlay: {
    position: 'absolute',
    top: -25,
    bottom: 0,
    left: 0,
    right: 0,
    resizeMode:'cover',
    
  }
});