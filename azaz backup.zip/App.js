import React from 'react';
import { NavigationContainer } from '@react-navigation/native';


//Navigation
import HomeScreenNavigation from './navigation/HomeNavigation';

export default function App() {
  return (
    <NavigationContainer>
      <HomeScreenNavigation />
    </NavigationContainer>
  );
}
