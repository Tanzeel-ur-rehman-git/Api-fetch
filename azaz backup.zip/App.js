import React, { useEffect } from "react";
import { NavigationContainer } from '@react-navigation/native';
import * as Font from 'expo-font';
import { createStore, combineReducers, applyMiddleware, compose } from "redux";
import ReduxThunk from 'redux-thunk'
import { Provider } from "react-redux";


//Navigation
import HomeScreenNavigation from './navigation/HomeNavigation';


// Redux Reducer
import cartReducer from "./redux/Reducers/cart"




export default function App() {
useEffect(() => {
  (async () => await Font.loadAsync({
    Roboto: require('native-base/Fonts/Roboto.ttf'),
    Roboto_medium: require('native-base/Fonts/Roboto_medium.ttf'),
  }))();
  return () => {
  }
}, [])


const rootReducer = combineReducers({
  cart: cartReducer,
});


const composeEnhancer = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

const store = createStore(
  rootReducer,
  composeEnhancer(applyMiddleware(ReduxThunk)),
);
  
  return (
    <Provider store={store} >
    <NavigationContainer>
      <HomeScreenNavigation />
    </NavigationContainer>
    </Provider>
  );
}
