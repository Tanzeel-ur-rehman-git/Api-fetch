import React, { useEffect } from "react";
import { NavigationContainer } from '@react-navigation/native';
import * as Font from 'expo-font';

// redux
import {Provider} from 'react-redux';
import store from './redux/store';

//Navigation
import HomeScreenNavigation from './navigation/HomeNavigation';

export default function App() {
useEffect(() => {
  (async () => await Font.loadAsync({
    Roboto: require('native-base/Fonts/Roboto.ttf'),
    Roboto_medium: require('native-base/Fonts/Roboto_medium.ttf'),
  }))();
  return () => {
  }
}, [])

  
  return (
    <Provider store={store} >
    <NavigationContainer>
      <HomeScreenNavigation />
    </NavigationContainer>
    </Provider>
  );
}
