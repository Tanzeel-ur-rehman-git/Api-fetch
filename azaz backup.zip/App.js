import React, { useEffect } from "react";
import { NavigationContainer } from '@react-navigation/native';
import * as Font from 'expo-font';



//Navigation
import HomeScreenNavigation from './navigation/HomeNavigation';

export default function App() {
useEffect(() => {
  (async () => await Font.loadAsync({
    Roboto: require('native-base/Fonts/Roboto.ttf'),
    Roboto_medium: require('native-base/Fonts/Roboto_medium.ttf'),
  }))();
  return () => {
  }
}, [])

  
  return (
    <NavigationContainer>
      <HomeScreenNavigation />
    </NavigationContainer>
  );
}
