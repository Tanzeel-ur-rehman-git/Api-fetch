import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';

//Screens
import LoginScreen from '../screens/LoginScreen';
import RegisterScreen from '../screens/RegisterScreen';
import Searchscreen from '../screens/Searchscreen';
import SplashScreen from '../screens/SplashScreen';
import OnboardingScreen from '../screens/OnboardingScreen';
import Test from '../screens/Test';
import TrendingScreen from '../screens/TrendingScreen';
import MainCart from '../cart/MainCart';
import GuestProfile from '../screens/GuestProfile';
import UserProfile from '../screens/UserProfile';

//Naviogation
import BottomTabNavigation from './BottomTabNavigation';

const Stack = createStackNavigator();

function MyStack(){
    return(
        <Stack.Navigator initialRouteName="Splash"
        screenOptions={{
        headerShown: false
      }}
      >
        <Stack.Screen name="Home" component={BottomTabNavigation} />
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Register" component={RegisterScreen} />
        <Stack.Screen name="Search" component={Searchscreen} />
        <Stack.Screen name="Splash" component={SplashScreen} />
        <Stack.Screen name="Onboarding" component={OnboardingScreen} />
        <Stack.Screen name="Test" component={Test} />
        <Stack.Screen name="Trending" component={TrendingScreen} />
        <Stack.Screen name="MainCart" component={MainCart} />
        <Stack.Screen name="GuestProfile" component={GuestProfile} />
        <Stack.Screen name="UserProfile" component={UserProfile} />


      </Stack.Navigator>
    )
}

export default function HomeNavigation(){
    return <MyStack />
}