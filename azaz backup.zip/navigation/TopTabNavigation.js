import React from "react";
import { createMaterialTopTabNavigator } from "@react-navigation/material-top-tabs";
import {SafeAreaView} from 'react-native';

//Screens
import AddAddress from "../cart/Checkout/AddAddress";
import AddPayment from "../cart/Checkout/AddPayment";
import ConfirmPayment from "../cart/Checkout/ConfirmPayment";

const Tab = createMaterialTopTabNavigator();

function MyTabs() {
  return (
    <Tab.Navigator   
    initialRouteName="AddAddress"
      tabBarOptions={{
        activeTintColor: '#e91e63',
        labelStyle: { fontSize: 11 ,fontWeight:'bold'},
        style: { backgroundColor: 'white',height:80,paddingTop:30 },
      }}
    >
      <Tab.Screen name="AddAddress" component={AddAddress} />
      <Tab.Screen name="ConfirmPayment" component={ConfirmPayment} />
      <Tab.Screen name="AddPayment" component={AddPayment} />

    </Tab.Navigator>
  );
}

export default function TopTabNavigation() {
  return(
       <MyTabs />
  ) 
}
