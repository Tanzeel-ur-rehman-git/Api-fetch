import React, { useEffect,useState } from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import Icon from "react-native-vector-icons/Octicons";
import MaterialIcons from "react-native-vector-icons/MaterialIcons";
import FontAwesome5 from "react-native-vector-icons/FontAwesome5";
import Fontisto from "react-native-vector-icons/Fontisto";
import AsyncStorage from "@react-native-async-storage/async-storage";

// import { Icon } from "native-base";

//Drawer Navigation
import DrawerNavigation from "./DrawerNavigtion";

//Screens
import TrendingScreen from "../screens/TrendingScreen";
import MainCart from "../cart/MainCart";
import DealScreen from "../screens/DealScreen";
import GuestProfile from "../screens/GuestProfile";
import UserProfile from "../screens/UserProfile";

const Tab = createBottomTabNavigator();

function MYBottom() {
  const [checkValue, setcheckValue] = useState(null)
  
    const tokenlogin = async () => {
    const value = await AsyncStorage.getItem("token");
    if (value !== null) {
         setcheckValue(value);
    } else {
      return null
    }
  };

  useEffect(() => {
    tokenlogin();
    return () => {
      
    }
  }, [])
  

  return (
    <Tab.Navigator
      initialRouteName="Home"
      tabBarOptions={{
        keyboardHidesTabBar: true,
        showLabel: false,
        activeTintColor: "#4682b4",
        inactiveTintColor: "#ff6347",
      }}
    >
      <Tab.Screen
        name="Home"
        component={DrawerNavigation}
        options={{
          tabBarIcon: ({ color }) => (
            <FontAwesome5 name="home" color={color} size={25} />
          ),
        }}
      />
      <Tab.Screen
        name="Trending"
        component={TrendingScreen}
        options={{
          tabBarIcon: ({ color }) => (
            <Icon name="flame" color={color} size={25} />
          ),
        }}
      />
      <Tab.Screen
        name="Cart"
        component={MainCart}
        options={{
          tabBarIcon: ({ color }) => (
            <MaterialIcons
              name="child-friendly"
              color={color}
              size={50}
              style={{ top: -19 }}
            />
          ),
        }}
      />

      <Tab.Screen
        name="Deals's"
        component={DealScreen}
        options={{
          tabBarIcon: ({ color }) => (
            <MaterialIcons name="fastfood" color={color} size={25} />
          ),
        }}
      />
      {checkValue == null ? (
        <Tab.Screen
        name="profile"
        component={GuestProfile}
        options={{
          tabBarIcon: ({ color }) => (
            <Fontisto name="person" color={color} size={25} />
          ),
        }}
      />
      ):(
        <Tab.Screen
        name="profile"
        component={UserProfile}
        options={{
          tabBarIcon: ({ color }) => (
            <Fontisto name="person" color={color} size={30} />
          ),
        }}
      />
      )}
      
    </Tab.Navigator>
  );
}

export default function BottomTabNavigation() {
  return <MYBottom />;
}
