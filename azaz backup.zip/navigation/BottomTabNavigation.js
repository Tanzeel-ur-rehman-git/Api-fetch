import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Icon from 'react-native-vector-icons/Octicons';
import Ficon from 'react-native-vector-icons/FontAwesome';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import Fontisto from 'react-native-vector-icons/Fontisto';


// import { Icon } from "native-base";

//Drawer Navigation
import DrawerNavigation from './DrawerNavigtion';

//Screens
import ProfileScreen from '../screens/ProfileScreen';
import Test from '../screens/Test';
import Logout from '../screens/Logput';

const Tab = createBottomTabNavigator();


function MyBottom(){
  return(
    <Tab.Navigator
    initialRouteName="Home"
    tabBarOptions={{
        keyboardHidesTabBar:true,
        showLabel:false,
        activeTintColor:'#ff6347',
        inactiveTintColor:'#4682b4'
        
    }}
    >
      <Tab.Screen 
      name="Home" 
      component={DrawerNavigation}
      options={{
          tabBarIcon: ({ color }) => (
              <FontAwesome5 name="home" color={color} size={30} />
              
            ),
      }}
      />
        <Tab.Screen 
      name="Profile" 
      component={ProfileScreen}
      options={{
          tabBarIcon: ({ color }) => (
              <Icon name="flame" color={color} size={30} />
            ),
      }}
      />
        <Tab.Screen 
      name="Test" 
      component={Test}
      options={{
          tabBarIcon: ({ color }) => (
              <MaterialIcons name="child-friendly" color={color} size={50} style={{top:-19}}/>
              
            ),
      }}
      />
      
        <Tab.Screen 
      name="MAP" 
      component={ProfileScreen}
      options={{
          tabBarIcon: ({ color }) => (
              <MaterialIcons name="fastfood" color={color} size={30} />
            ),
      }}
      />

<Tab.Screen 
      name="Logout" 
      component={ProfileScreen}
      options={{
          tabBarIcon: ({ color }) => (
              <Fontisto name="person" color={color} size={30} />
            ),
      }}
      />

    </Tab.Navigator>
  )}

  export default function  BottomTabNavigation(){
    return <MyBottom />
  }