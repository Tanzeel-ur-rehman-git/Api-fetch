import React from "react";
import { createDrawerNavigator} from "@react-navigation/drawer";

//Drawer Content
import DrawerCustomContent from './DrawerContent';

//Screens
import HomeScreen from "../screens/HomeScreen";

const Drawer = createDrawerNavigator();


function MyDrawer() {
  return (
    <Drawer.Navigator
      initialRouteName="Home"
      drawerContent={(props) => <DrawerCustomContent {...props} />}
    >
      <Drawer.Screen name="Home" component={HomeScreen}/>
    </Drawer.Navigator>
  );
}

export default function DrawerNavigtion() {
  return <MyDrawer />;
}
