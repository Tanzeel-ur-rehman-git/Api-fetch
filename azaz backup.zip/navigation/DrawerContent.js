import React from "react";
import { Icon } from "native-base";
import { Drawer } from "react-native-paper";
import { DrawerContentScrollView, DrawerItem } from "@react-navigation/drawer";
import { StyleSheet, Text, View, SafeAreaView, Dimensions } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const DrawContent = (props) => {
  const logout = async () => {
    await AsyncStorage.removeItem("token");
    props.navigation.navigate("Login");
  };

  return (
    <View style={{ flex: 1 }}>
      <DrawerContentScrollView {...props}>
        <Drawer.Section>
          <DrawerItem
            icon={() => (
              <Icon
                type="FontAwesome5"
                name="home"
                style={{ fontSize: 35, color: "orange" }}
              />
            )}
            label="Home"
            onPress={() => {
              props.navigation.navigate("Home");
            }}
          />
          <DrawerItem
            icon={() => (
              <Icon
              type="FontAwesome5"
              name="money-check"
              style={{ fontSize: 35, color: "brown" }}
            />
            )}
            label="Wallet"
            onPress={() => {
              props.navigation.navigate("Home");
            }}
          />
          <DrawerItem
            icon={() => (
              <Icon
              type="FontAwesome5"
              name="history"
              style={{ fontSize: 35, color: "#2e8b57" }}
            />
            )}
            label="Orders History"
            onPress={() => {
              props.navigation.navigate("Home");
            }}
          />
          <DrawerItem
            icon={() => (
              <Icon
              type="Entypo"
              name="price-tag"
              style={{ fontSize: 35, color: "gold" }}
            />
            )}
            label="Vouchers"
            onPress={() => {
              props.navigation.navigate("Home");
            }}
          />
          <DrawerItem
            icon={() => (
              <Icon
              type="FontAwesome5"
              name="users"
              style={{ fontSize: 35, color: "#007FFF" }}
            />
            )}
            label="Refer A friend"
            onPress={() => {
              props.navigation.navigate("Home");
            }}
          />
          <DrawerItem
            icon={() => (
               <Icon
                type="Entypo"
                name="chat"
                style={{ fontSize: 35, color: "#e0115f" }}
              />
            )}
            label="Help Center"
            onPress={() => {
              props.navigation.navigate("Home");
            }}
          />

          <DrawerItem
            icon={() => (
               <Icon
                type="MaterialCommunityIcons"
                name="account-question"
                style={{ fontSize: 35, color: "#882d17" }}
              />
            )}
            label="FAQs"
            onPress={() => {
              props.navigation.navigate("Home");
            }}
          />
          <DrawerItem
            icon={() => (
               <Icon
                type="AntDesign"
                name="star"
                style={{ fontSize: 35, color: "#4682b4" }}
              />
            )}
            label="Review US"
            onPress={() => {
              props.navigation.navigate("Home");
            }}
          />
          <DrawerItem
            icon={() => (
               <Icon
                type="FontAwesome5"
                name="share-alt"
                style={{ fontSize: 35, color: "#8db600" }}
              />
            )}
            label="Share With Friend"
            onPress={() => {
              props.navigation.navigate("Home");
            }}
          />
        </Drawer.Section>
      </DrawerContentScrollView>
      <Drawer.Section style={styles.bottomDrawerSection}>
        <DrawerItem
          icon={() => (
             <Icon
                type="MaterialIcons"
                name="privacy-tip"
                style={{ fontSize: 35, color: "green" }}
              />
          )}
          label="Privacy Policy"
          onPress={() => {
            logout();
          }}
        />
        <DrawerItem
          icon={() => (
             <Icon
                type="MaterialIcons"
                name="policy"
                style={{ fontSize: 35, color: "#FF00FF" }}
              />
          )}
          label="Terms Conditions"
          onPress={() => {
            logout();
          }}
        />
        <DrawerItem
          icon={() => (
             <Icon
                type="FontAwesome"
                name="sign-out"
                style={{ fontSize: 35, color: "red" }}
              />
          )}
          label="Sign Out"
          onPress={() => {
            logout();
          }}
        />
      </Drawer.Section>
    </View>
  );
};
const styles = StyleSheet.create({
  drawerContent: {
    flex: 1,
  },

  bottomDrawerSection: {
    marginBottom: 15,
    borderTopColor: "#f4f4f4",
    borderTopWidth: 1,
  },
  preference: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  image: {
    width: 200,
    resizeMode: "contain",
    top: -100,
  },
});

export default DrawContent;
