import React, { useEffect, useState } from "react";
import { Icon } from "native-base";
import { Drawer } from "react-native-paper";
import { DrawerContentScrollView, DrawerItem } from "@react-navigation/drawer";
import {
  StyleSheet,
  View,
  Share,
  Platform,
  Linking,
  Image,
  Dimensions,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const DrawContent = (props) => {
  const [checkValue, setcheckValue] = useState(null);
  const logout = async () => {
    await AsyncStorage.removeItem("token");
    props.navigation.navigate("Login");
  };

  const tokenlogin = async () => {
    const value = await AsyncStorage.getItem("token");
    if (value !== null) {
      setcheckValue(value);
    } else {
      return null;
    }
  };

  useEffect(() => {
    tokenlogin();
    return () => {};
  }, []);

  const IosShare = async () => {
    try {
      const result = await Share.share({
        title: "Fattafatt Home Delivery",
        message: "Please install this app and stay safe IOS",
        url: "https://www.apple.com/app-store/",
        subject: "Get Amazing Food Deals",
      });
      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // shared with activity type of result.activityType
        } else {
          // shared
        }
      } else if (result.action === Share.dismissedAction) {
        // dismissed
      }
    } catch (error) {
      alert(error.message);
    }
  };

  const AndroidShare = async () => {
    try {
      const result = await Share.share({
        dialogTitle: "Fattafatt Home Delivery",
        title: "Fattafatt Home Delivery",
        message:
          "Please install this app and stay safe  Android, AppLink https://play.google.com/store/apps/details?id=com.smartherd.fatafat&hl=en&gl=US",
      });
      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // shared with activity type of result.activityType
        } else {
          // shared
        }
      } else if (result.action === Share.dismissedAction) {
        // dismissed
      }
    } catch (error) {
      alert(error.message);
    }
  };

  const shareSelect = () => {
    Platform.OS === "ios" ? IosShare() : AndroidShare();
  };

  const reviewusSelect = () => {
    Platform.OS === "ios"
      ? Linking.openURL("https://www.apple.com/app-store/")
      : Linking.openURL(
          "https://play.google.com/store/apps/details?id=com.smartherd.fatafat&hl=en&gl=US"
        );
  };

  return (
    <View style={{ flex: 1 }}>
      <DrawerContentScrollView {...props}>
        <View style={{ alignItems: "center", marginBottom: -40 }}>
          <Image
            style={{
              width: Dimensions.get("window").width / 2 + 75,
              height: 200,
              resizeMode: "contain",
              top: -20,
            }}
            source={require("../assets/images/logo.png")}
          />
        </View>
        <Drawer.Section>
          <DrawerItem
            icon={() => (
              <Icon
                type="FontAwesome5"
                name="home"
                style={{ fontSize: 25, color: "#ff6347" }}
              />
            )}
            label="Home"
            onPress={() => {
              props.navigation.navigate("Home");
            }}
            style={{ backgroundColor: "#ffff" }}
            labelStyle={{}}
          />
          {checkValue == null ? null : (
            <DrawerItem
              style={{}}
              icon={() => (
                <Icon
                  type="FontAwesome5"
                  name="money-check"
                  style={{ fontSize: 25, color: "#ff6347" }}
                />
              )}
              label="Wallet"
              onPress={() => {
                props.navigation.navigate("WalletScreen");
              }}
              style={{ backgroundColor: "#ffff" }}
              labelStyle={{ left: -6 }}
            />
          )}
          {checkValue == null ? null : (
            <DrawerItem
              icon={() => (
                <Icon
                  type="FontAwesome5"
                  name="history"
                  style={{ fontSize: 25, color: "#ff6347" }}
                />
              )}
              label="Orders History"
              onPress={() => {
                props.navigation.navigate("OrderHistory");
              }}
              style={{ backgroundColor: "#ffff" }}
              labelStyle={{}}
            />
          )}
          <DrawerItem
            icon={() => (
              <Icon
                type="Entypo"
                name="price-tag"
                style={{ fontSize: 25, color: "#ff6347" }}
              />
            )}
            label="Vouchers"
            onPress={() => {
              props.navigation.navigate("VoucherScreen");
            }}
            style={{ backgroundColor: "#ffff" }}
            labelStyle={{}}
          />
          {checkValue == null ? null : (
            <DrawerItem
              icon={() => (
                <Icon
                  type="FontAwesome5"
                  name="users"
                  style={{ fontSize: 25, color: "#ff6347" }}
                />
              )}
              label="Refer A friend"
              onPress={() => {
                props.navigation.navigate("ReferFriendScreen");
              }}
              style={{ backgroundColor: "#ffff" }}
              labelStyle={{ left: -8 }}
            />
          )}
          <DrawerItem
            icon={() => (
              <Icon
                type="Entypo"
                name="chat"
                style={{ fontSize: 25, color: "#ff6347" }}
              />
            )}
            label="Help Center"
            onPress={() => {
              props.navigation.navigate("HelpCenter");
            }}
            style={{ backgroundColor: "#ffff" }}
            labelStyle={{}}
          />

          <DrawerItem
            icon={() => (
              <Icon
                type="MaterialCommunityIcons"
                name="account-question"
                style={{ fontSize: 25, color: "#ff6347" }}
              />
            )}
            label="FAQs"
            onPress={() => {
              props.navigation.navigate("FAQScreen");
            }}
            style={{ backgroundColor: "#ffff" }}
            labelStyle={{}}
          />
          <DrawerItem
            icon={() => (
              <Icon
                type="AntDesign"
                name="star"
                style={{ fontSize: 25, color: "#ff6347" }}
              />
            )}
            label="Review US"
            onPress={reviewusSelect}
            style={{ backgroundColor: "#ffff" }}
            labelStyle={{}}
          />
          <DrawerItem
            icon={() => (
              <Icon
                type="FontAwesome5"
                name="share-alt"
                style={{ fontSize: 25, color: "#ff6347" }}
              />
            )}
            label="Share With Friend"
            onPress={shareSelect}
            style={{ backgroundColor: "#ffff" }}
            labelStyle={{}}
          />
        </Drawer.Section>
      </DrawerContentScrollView>
      <Drawer.Section style={styles.bottomDrawerSection}>
        <DrawerItem
          style={{ marginBottom: -10 }}
          icon={() => (
            <Icon
              type="MaterialIcons"
              name="privacy-tip"
              style={{ fontSize: 25, color: "green" }}
            />
          )}
          label="Privacy Policy"
          onPress={() => {
            props.navigation.navigate("PrivacyPolicy");
          }}
        />
        <DrawerItem
          style={{ marginBottom: -10 }}
          icon={() => (
            <Icon
              type="MaterialIcons"
              name="policy"
              style={{ fontSize: 25, color: "#FF00FF" }}
            />
          )}
          label="Terms Conditions"
          onPress={() => {
            props.navigation.navigate("TermsCondition");
          }}
        />
        {checkValue == null ? null : (
          <DrawerItem
            icon={() => (
              <Icon
                type="FontAwesome"
                name="sign-out"
                style={{ fontSize: 25, color: "red" }}
              />
            )}
            label="Sign Out"
            onPress={() => {
              logout();
            }}
          />
        )}
      </Drawer.Section>
    </View>
  );
};
const styles = StyleSheet.create({
  drawerContent: {
    flex: 1,
  },

  bottomDrawerSection: {
    marginBottom: 15,
    borderTopColor: "#f4f4f4",
    borderTopWidth: 1,
  },
  preference: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  image: {
    width: 200,
    resizeMode: "contain",
    top: -100,
  },
});

export default DrawContent;
