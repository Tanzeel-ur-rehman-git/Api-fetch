import { FETCHING_VENDORSLIST,FETCH_VENDORSLIST_SUCCESS,FETCH_VENDORSLIST_FAILURE } from '../constants';

const initialState = {
    VendorsReducers: [],
    isFetching: false,
    error: false
}

export default function VReducers(state = initialState, action) {

    switch(action.type) {
        case FETCHING_VENDORSLIST:
            return {
                ...state,
                isFetching: true
            }
        case FETCH_VENDORSLIST_SUCCESS:
            return {
                ...state,
                isFetching: false,
                VendorsReducers: action.data
            }
        case FETCH_VENDORSLIST_FAILURE:
            return {
                ...state,
                isFetching: false,
                error: true
            }
        default:
            return state
    }
}