import {
  ADD_TO_CART,
  REMOVE_FROM_CART,
  CLEAR_CART,
  INCREMENT_TO_CART,
  DECREMENT_TO_CART
} from '../constants';

import CartItem from '../../models/cart-item';


const initialState = {
  items: {},
  totalAmount: 0,
};


const cartItems = (state = initialState, action) => {
  switch (action.type) {
      case ADD_TO_CART:
        const product = action.payload;
        //check if product is already in cart
        const cartItemId = product.id;
        console.log(cartItemId)
        if (state.items[cartItemId]) {
          const item = state.items[cartItemId];
          // item is already in cart
          const updatedCartItem = new CartItem(
            item.quantity + 1,
            item.productPrice,
            item.productTitle,
            item.sum + product.productPrice
          );
          return {
            ...state,
            items: { ...state.items, [cartItemId]: updatedCartItem },
            totalAmount: state.totalAmount + product.productPrice,
          };
        } else {
          //create new cart item
          const cartItem = new CartItem(
            1,
            product.productPrice,
            product.productTitle,
            product.productPrice
          );
  
          //add product to cart
          return {
            //copy state, copy items, add new item
            ...state,
            items: { ...state.items, [cartItemId]: cartItem },
            totalAmount: state.totalAmount + product.productPrice,
          };
        }



        
      case REMOVE_FROM_CART:
        const selectedCartItem = state.items[action.payload];
        console.log(state.items)
        let updatedCartItems;
          updatedCartItems = { ...state.items };
          delete updatedCartItems[action.payload];  
        return {
          ...state,
          items: updatedCartItems,
          totalAmount: state.totalAmount - selectedCartItem.productPrice,
        };





        
      case CLEAR_CART:
          return {
            ...state,
            items:{}
          }







      case INCREMENT_TO_CART:
        const incrementCartItem = state.items[action.payload];
        const beforeIncrementQuantity = state.items[action.payload].quantity;
  
        let incrementUpdatedCartItem;
  
        if (beforeIncrementQuantity > 0) {
          //reduce
          const updatedCartItem = new CartItem(
            incrementCartItem.quantity + 1,
            incrementCartItem.productPrice,
            incrementCartItem.productTitle,
            incrementCartItem.sum + incrementCartItem.productPrice
          );
  
          incrementUpdatedCartItem = {
            ...state.items,
            [action.payload]: updatedCartItem,
          };
        } else {
          //erase
          incrementUpdatedCartItem = { ...state.items };
          delete incrementUpdatedCartItem[action.payload];
        }
  
        return {
          ...state,
          items: incrementUpdatedCartItem,
          totalAmount: state.totalAmount + incrementCartItem.productPrice,
        };








      case DECREMENT_TO_CART:
        const decrementCartItem = state.items[action.payload];
        const beforeDecrementQuantity = state.items[action.payload].quantity;
  
        let decrementUpdatedCartItem;
  
        if (beforeDecrementQuantity > 1) {
          //reduce
          const updatedCartItem = new CartItem(
            decrementCartItem.quantity - 1,
            decrementCartItem.productPrice,
            decrementCartItem.productTitle,
            decrementCartItem.sum - decrementCartItem.productPrice
          );
  
          decrementUpdatedCartItem = {
            ...state.items,
            [action.payload]: updatedCartItem,
          };
        } else {
          //erase
          decrementUpdatedCartItem = { ...state.items };
          delete decrementUpdatedCartItem[action.payload];
        }
  
        return {
          ...state,
          items: decrementUpdatedCartItem,
          totalAmount: state.totalAmount - decrementCartItem.productPrice,
        };
  }
  return state;
}

export default cartItems;