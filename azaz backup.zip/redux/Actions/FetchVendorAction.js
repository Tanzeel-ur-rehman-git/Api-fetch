import { FETCHING_VENDORSLIST, FETCH_VENDORSLIST_FAILURE,FETCH_VENDORSLIST_SUCCESS } from '../constants';
import axios from 'axios';

export function FetchVendorAction() {

    return (dispatch) => {
        dispatch(getVendors())
        axios.get('https://fattafatt.com/api/v1/user_actions.php?all_vendor=%27%27&city=1')
            .then(function (response) {

                // handle your response here, create an object/array/array of objects etc... 
                // and return it in dispatch(getToDosSuccess(data over here))

                return(dispatch(getVendorsSuccess(response.data)))
            })
            .catch(err => dispatch(getVendorsFailure(err)))
    }
}

function getVendors() {

    return {
        type: FETCHING_VENDORSLIST
    }
}

function getVendorsSuccess(data) {

    return {
        type: FETCH_VENDORSLIST_SUCCESS,
        data
    }
}

function getVendorsFailure() {
    return {
        type: FETCH_VENDORSLIST_FAILURE
    }
}